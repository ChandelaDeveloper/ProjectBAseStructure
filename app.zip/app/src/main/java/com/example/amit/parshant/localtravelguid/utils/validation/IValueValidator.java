package com.example.amit.parshant.localtravelguid.utils.validation;

/**
 * Created by JSN on 12/9/17.
 */

public interface IValueValidator {
    boolean validate(String value);

    String getErrorMsg();
}
