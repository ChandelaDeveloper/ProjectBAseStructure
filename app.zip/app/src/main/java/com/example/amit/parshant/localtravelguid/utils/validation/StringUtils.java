package com.example.amit.parshant.localtravelguid.utils.validation;

/**
 * Created by JSN on 12/9/17.
 */

public class StringUtils {

    public static boolean validString(String value) {
        return !invalidString(value);
    }

    public static boolean invalidString(String value) {
        return value == null || value.trim().equals("");
    }
}
