package com.example.amit.parshant.localtravelguid.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.NestedScrollView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.example.amit.parshant.localtravelguid.activities.BaseActivity;
import com.example.amit.parshant.localtravelguid.mvvp.views.BaseView;

import retrofit2.Response;


/**
 * Created by signity on 13/11/17.
 */

public abstract class BaseFragment extends Fragment implements BaseView {

    protected int mScreenwidth, mScreenheight;
    protected BaseActivity mActivity;
    /**
     * Used in replacement for getActivity();
     * Since getActivity() may leads to null; if fragment is detached, thereby used in onAttach and onDetach methods
     * Do check null before using every time.
     */
    protected Context mContext;

    @Override
    public void onAttach(Activity activity) {
        // TODO Auto-generated method stub
        super.onAttach(activity);
        mContext = activity;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mContext = null;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        /**
         * Assuming each activity will be extended by BaseActivity
         */
        mActivity = (BaseActivity) this.getActivity();
        getScreenDimens();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(getLayoutResID(), container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI();
        initListeners();
        onCreateView(savedInstanceState);
    }

    /**
     * replacement of findViewByID; will help eliminating the view.findViewByID in fragment
     * makes it generally same like done in Activity
     *
     * @param resId
     * @return
     */
    public <T extends View> T findViewById(@IdRes int resId) {
        return getView().findViewById(resId);
    }

    /**
     * resource id of layout like R.id..
     *
     * @return id of the resource mentioned
     */
    @LayoutRes
    public abstract int getLayoutResID();

    /**
     * Can be used same like onCreate(@Nullable Bundle savedInstanceState)
     * also for onViewCreated
     *
     * @param savedInstanceState
     */
    public abstract void onCreateView(@Nullable Bundle savedInstanceState);

    /**
     * initiate the UI elements here
     */
    public abstract void initUI();

    /**
     * initialize listeners like onClick, onItemClick, etc here
     */
    public abstract void initListeners();

    /**
     * Screen dimensions in pixels;
     */
    void getScreenDimens() {
       mScreenwidth= mActivity.mScreenwidth;
       mScreenheight= mActivity.mScreenheight;
    }

    /**
     * is called when :public void onFailure(Call<RetroResponse.LoginResponse> call, Throwable t)
     */
    @Override
    public void onRetroRequestFailure() {

    }

    /**
     * When retrofit returns in onSuccess(Response<?> response) and response is not successful
     *
     * @param response
     */
    @Override
    public void onError(Response<?> response) {
        mActivity.onError(response);
    }

    /**
     * If internet is not present show error dialog here
     */
    @Override
    public void showNoInternetDialog() {
        mActivity.showNoInternetDialog();
    }

    /**
     * Show loader when required
     */
    @Override
    public void showLoadingDialog() {
        mActivity.showLoadingDialog();
    }
    /**
     * Show loader when required with custom message
     */
    @Override
    public void showLoadingDialog(String msg) {
        mActivity.showLoadingDialog(msg);
    }


    /**
     * Hide loading dialog
     */
    @Override
    public void hideLoadingDialog() {
        mActivity.hideLoadingDialog();
    }

    /**
     * To show toast messages in app
     *
     * @param msg : hold message info
     */

    public void showToast(String msg) {
        mActivity.showToast(msg);
    }


    /**
     * Use to transfer user to next screen
     *
     * @param current: current activity
     * @param next     : next activity
     * @param flag     :flag for intent
     */
    void navigateToNextScreen(Context current, Class<?> next, int flag) {
        mActivity.navigateToNextScreen(current, next, flag);
    }

    /**
     * Use to transfer user to next screen
     *
     * @param current: current activity
     * @param next     : next activity
     * @param flag     :flag for intent
     * @param bundle
     */

    public void navigateToNextScreen(Context current, Class<?> next, int flag, Bundle bundle) {
        mActivity.navigateToNextScreen(current, next, flag, bundle);
    }

    /**
     * Use to transfer user to next screen
     *
     * @param current: current activity
     * @param next     : next activity
     */
    public void navigateToNextScreen(Context current, Class<?> next) {
        mActivity.navigateToNextScreen(current, next);
    }

    /**
     * Use to transfer user to next screen
     *
     * @param current: current activity
     * @param next     : next activity
     */
    public void navigateToNextScreenForResult(Context current, Class<?> next, int requestCode) {
        mActivity.navigateToNextScreenForResult(current, next, requestCode);
    }

    /**
     * Use to transfer user to next screen
     *
     * @param current: current activity
     * @param next     : next activity
     * @param bundle   : data
     */
    public void navigateToNextScreen(Context current, Class<?> next, Bundle bundle) {
        mActivity.navigateToNextScreen(current, next, bundle);
    }


    /**
     * Use to show info message as a pop up
     *
     * @param message : hold info to display
     */
    public void infoAlertDialog(String message) {
        mActivity.infoAlertDialog(message);
    }

    /**
     * Use to show info message as a pop up
     *
     * @param message : hold info to display
     * @param title   :to display requied title
     */
    public void infoAlertDialog(String title, String message) {
        mActivity.infoAlertDialog(title, message);
    }

    /**
     * To show message and ask for user confirmation
     *
     * @param message  :hold info message text
     * @param positive :to show positive button text on dialog
     * @param negative :to show negative button text on dialog
     */
    public void confirmationAlertDialog(String message, String positive, String negative) {
        mActivity.confirmationAlertDialog(message, positive, negative);
    }

    /**
     * To show message and ask for user confirmation
     *
     * @param message  :hold info message text
     * @param positive :to show positive button text on dialog
     * @param negative :to show negative button text on dialog
     * @param title    :to display requied title
     */
    public void confirmationAlertDialog(String title, String message, String positive, String negative) {
        mActivity.confirmationAlertDialog(title, message, positive, negative);
    }


    ///scroll scroll view to bottom
    void scrollDown(final NestedScrollView scrollView) {
        mActivity.scrollDown(scrollView);
    }

    ///scroll scroll view to TOP
    void scrollUp(final NestedScrollView scrollView) {
        mActivity.scrollUp(scrollView);
    }
}
