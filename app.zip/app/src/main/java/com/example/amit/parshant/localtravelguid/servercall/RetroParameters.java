package com.example.amit.parshant.localtravelguid.servercall;

/**
 * Created by signity on 13/11/17.
 */

public class RetroParameters {
}
