package com.example.amit.parshant.localtravelguid.utils.validation;

/**
 * Created by JSN on 12/9/17.
 */

public interface IValidator {
    boolean validate();
    void setError(String msg);
}
