package com.example.amit.parshant.localtravelguid.servercall;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by signity on 13/11/17.
 */
public class RetroResponse {

    //Login api response
    public static class LoginResponse {

        @SerializedName("status")
        private int status;
        @SerializedName("message")
        private String message;
        @SerializedName("data")
        private Data data;

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Data getData() {
            return data;
        }

        public void setData(Data data) {
            this.data = data;
        }

        public class Data {
            @SerializedName("id_old")
            private int idOld;
            @SerializedName("company_id")
            private int companyId;
            @SerializedName("display_name")
            private String displayName;
            @SerializedName("email")
            private String email;
            @SerializedName("linkedin")
            private Object linkedin;
            @SerializedName("image_url")
            private String imageUrl;
            @SerializedName("dob")
            private String dob;
            @SerializedName("gender")
            private String gender;
            @SerializedName("type")
            private String type;
            @SerializedName("bio")
            private Object bio;
            @SerializedName("status")
            private int status;
            @SerializedName("created")
            private String created;
            @SerializedName("modified")
            private String modified;
            @SerializedName("cur_role")
            private int curRole;
            @SerializedName("add_role")
            private int addRole;
            @SerializedName("access_routes")
            private String accessRoutes;
            @SerializedName("id")
            private String id;
            @SerializedName("reporting_manager")
            private String reportingManager;
            @SerializedName("comp_routes")
            private String compRoutes;
            @SerializedName("password_changed")
            private String passwordChanged;
            @SerializedName("token")
            private String token;

            public int getIdOld() {
                return idOld;
            }

            public void setIdOld(int idOld) {
                this.idOld = idOld;
            }

            public int getCompanyId() {
                return companyId;
            }

            public void setCompanyId(int companyId) {
                this.companyId = companyId;
            }

            public String getDisplayName() {
                return displayName;
            }

            public void setDisplayName(String displayName) {
                this.displayName = displayName;
            }

            public String getEmail() {
                return email;
            }

            public void setEmail(String email) {
                this.email = email;
            }

            public Object getLinkedin() {
                return linkedin;
            }

            public void setLinkedin(Object linkedin) {
                this.linkedin = linkedin;
            }

            public String getImageUrl() {
                return imageUrl;
            }

            public void setImageUrl(String imageUrl) {
                this.imageUrl = imageUrl;
            }

            public String getDob() {
                return dob;
            }

            public void setDob(String dob) {
                this.dob = dob;
            }

            public String getGender() {
                return gender;
            }

            public void setGender(String gender) {
                this.gender = gender;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public Object getBio() {
                return bio;
            }

            public void setBio(Object bio) {
                this.bio = bio;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public String getCreated() {
                return created;
            }

            public void setCreated(String created) {
                this.created = created;
            }

            public String getModified() {
                return modified;
            }

            public void setModified(String modified) {
                this.modified = modified;
            }

            public int getCurRole() {
                return curRole;
            }

            public void setCurRole(int curRole) {
                this.curRole = curRole;
            }

            public int getAddRole() {
                return addRole;
            }

            public void setAddRole(int addRole) {
                this.addRole = addRole;
            }

            public String getAccessRoutes() {
                return accessRoutes;
            }

            public void setAccessRoutes(String accessRoutes) {
                this.accessRoutes = accessRoutes;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getReportingManager() {
                return reportingManager;
            }

            public void setReportingManager(String reportingManager) {
                this.reportingManager = reportingManager;
            }

            public String getCompRoutes() {
                return compRoutes;
            }

            public void setCompRoutes(String compRoutes) {
                this.compRoutes = compRoutes;
            }

            public String getPasswordChanged() {
                return passwordChanged;
            }

            public void setPasswordChanged(String passwordChanged) {
                this.passwordChanged = passwordChanged;
            }

            public String getToken() {
                return token;
            }

            public void setToken(String token) {
                this.token = token;
            }

        }
    }

    // api response
    public static class ApiResponse {

        public String data;
        @SerializedName("status")
        private Integer status;
        @SerializedName("message")
        private String message;


        public Integer getStatus() {
            return status;
        }

        public void setStatus(Integer status) {
            this.status = status;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;


        }
    }

    public static class DevPlanResponse {


        @SerializedName("status")
        private Integer status;
        @SerializedName("message")
        private String message;
        @SerializedName("data")
        private String id;


        public Integer getStatus() {
            return status;
        }

        public void setStatus(Integer status) {
            this.status = status;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;


        }
    }

    //Library response
    public static class LibraryResponse implements Serializable {

        @SerializedName("status")
        private Integer status;
        @SerializedName("message")
        private String message;
        @SerializedName("data")
        private Data data;

        public Data getData() {
            return data;
        }

        public void setData(Data data) {
            this.data = data;
        }

        public Integer getStatus() {
            return status;
        }

        public void setStatus(Integer status) {
            this.status = status;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public class Data implements Serializable {

            @SerializedName("library")
            public List<Library> library = null;
            @SerializedName("explore")
            public List<Explore> explore = null;

        }

        public class Explore implements Serializable {

            @SerializedName("abs_url")
            public String abs_url;
            @SerializedName("id")
            public int id;
            @SerializedName("title")
            public String title;
            @SerializedName("description")
            public String description;
            @SerializedName("video_url")
            public String videoUrl;
            @SerializedName("poster")
            public String poster;
            @SerializedName("comp_id")
            public String compId;
            @SerializedName("exp_id")
            public String expId;
            @SerializedName("status")
            public int status;

        }

        public class Library implements Serializable {

            @SerializedName("id")
            public int id;
            @SerializedName("title")
            public String title;
            @SerializedName("icon_url")
            public String iconUrl;

        }

    }

    public static class FetchLikeVideoResponse implements Serializable {

        @SerializedName("status")
        public int status;
        @SerializedName("message")
        public String message;
        @SerializedName("data")
        public List<likedVideoResponse> data = null;

        public static class likedVideoResponse implements Serializable {

            @SerializedName("abs_url")
            public String abs_url;
            @SerializedName("user_id")
            public String userId;
            @SerializedName("id")
            public int id;
            @SerializedName("modified")
            @Expose
            public String modified;
            @SerializedName("title")
            public String title;
            @SerializedName("description")
            public String description;
            @SerializedName("video_url")
            public String videoUrl;
            @SerializedName("poster")
            public String poster;
            @SerializedName("exp_id")
            public String expId;
            @SerializedName("comp_id")
            public String compId;
            @SerializedName("status")
            public int status;

        }

    }

    // get role api response
    public static class GetRoleApiResponse {

        @SerializedName("status")
        private Integer status;
        @SerializedName("message")
        private String message;
        @SerializedName("data")
        private List<Title> data = null;

        public Integer getStatus() {
            return status;
        }

        public void setStatus(Integer status) {
            this.status = status;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public List<Title> getData() {
            return data;
        }

        public void setData(List<Title> data) {
            this.data = data;
        }

    }

    public static class GetExperiencesResponse {

        @SerializedName("status")
        private Integer status;
        @SerializedName("message")
        private String message;
        @SerializedName("data")
        private List<Experiences> experiencesList = null;

        public Integer getStatus() {
            return status;
        }

        public void setStatus(Integer status) {
            this.status = status;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public List<Experiences> getExperiences() {
            return experiencesList;
        }

        public void setExperiences(List<Experiences> experiences) {
            this.experiencesList = experiences;
        }

    }

    public static class Experiences implements Parcelable, Serializable {
        public static final Creator<Experiences> CREATOR = new Creator<Experiences>() {
            @Override
            public Experiences createFromParcel(Parcel source) {
                return new Experiences(source);
            }

            @Override
            public Experiences[] newArray(int size) {
                return new Experiences[size];
            }
        };
        @SerializedName("id")
        private int id;
        @SerializedName("company_id")
        private int companyId;
        @SerializedName("experience_id")
        private String experienceId;
        @SerializedName("title")
        private String title;
        @SerializedName("subtitle")
        private String subtitle;
        @SerializedName("video_urls")
        private List<String> videoUrls = null;
        @SerializedName("description")
        private String description;
        @SerializedName("icon_url")
        private String iconUrl;
        @SerializedName("sort_order")
        private int sortOrder;
        @SerializedName("status")
        private int status;
        @SerializedName("created")
        private String created;
        @SerializedName("modified")
        private String modified;
        @SerializedName("comp_orig_id")
        private int compOrigId;
        @SerializedName("videos")
        private List<VideoUrls> posters = null;
        @SerializedName("exp_id")
        private int expId;
        private int pro_id;

        public Experiences() {
        }

        Experiences(Parcel source) {
            id = source.readInt();
            companyId = source.readInt();
            experienceId = source.readString();
            title = source.readString();
            subtitle = source.readString();
            videoUrls = source.readArrayList(String.class.getClassLoader());
            description = source.readString();
            iconUrl = source.readString();
            sortOrder = source.readInt();
            status = source.readInt();
            created = source.readString();
            modified = source.readString();
            compOrigId = source.readInt();
            posters = source.readArrayList(VideoUrls.class.getClassLoader());
            expId = source.readInt();
            pro_id = source.readInt();
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getExperienceId() {
            return experienceId;
        }

        public void setExperienceId(String experienceId) {
            this.experienceId = experienceId;
        }

        public String getSubtitle() {
            return subtitle;
        }

        public void setSubtitle(String subtitle) {
            this.subtitle = subtitle;
        }

        public int getCompanyId() {
            return companyId;
        }

        public void setCompanyId(int companyId) {
            this.companyId = companyId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public List<String> getVideoUrls() {
            return videoUrls;
        }

        public void setVideoUrls(List<String> videoUrls) {
            this.videoUrls = videoUrls;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getIconUrl() {
            return iconUrl;
        }

        public void setIconUrl(String iconUrl) {
            this.iconUrl = iconUrl;
        }

        public int getSortOrder() {
            return sortOrder;
        }

        public void setSortOrder(int sortOrder) {
            this.sortOrder = sortOrder;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getCreated() {
            return created;
        }

        public void setCreated(String created) {
            this.created = created;
        }

        public String getModified() {
            return modified;
        }

        public void setModified(String modified) {
            this.modified = modified;
        }

        public int getCompOrigId() {
            return compOrigId;
        }

        public void setCompOrigId(int compOrigId) {
            this.compOrigId = compOrigId;
        }

        public List<VideoUrls> getPosters() {
            return posters;
        }

        public void setPosters(List<VideoUrls> posters) {
            this.posters = posters;
        }

        public int getExpId() {
            return expId;
        }

        public void setExpId(int expId) {
            this.expId = expId;
        }

        public int getProId() {
            return pro_id;
        }

        public void setProId(int pro_id) {
            this.pro_id = pro_id;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(id);
            dest.writeInt(companyId);
            dest.writeString(experienceId);
            dest.writeString(title);
            dest.writeString(subtitle);
            dest.writeList(videoUrls);
            dest.writeString(description);
            dest.writeString(iconUrl);
            dest.writeInt(sortOrder);
            dest.writeInt(status);
            dest.writeString(created);
            dest.writeString(modified);
            dest.writeInt(compOrigId);
            dest.writeList(posters);
            dest.writeInt(expId);
            dest.writeInt(pro_id);
        }

        public static class VideoUrls implements Parcelable, Serializable {
            public static final Creator<VideoUrls> CREATOR = new Creator<VideoUrls>() {
                @Override
                public VideoUrls createFromParcel(Parcel in) {
                    return new VideoUrls(in);
                }

                @Override
                public VideoUrls[] newArray(int size) {
                    return new VideoUrls[size];
                }
            };
            @SerializedName("id")
            private int id;
            @SerializedName("experiences_id")
            private int experiencesId;
            @SerializedName("video_url")
            private String videoUrl;
            @SerializedName("created")
            private String created;
            @SerializedName("company_id")
            private int companyId;
            @SerializedName("poster")
            private String poster;
            @SerializedName("status")
            private int status;
            @SerializedName("abs_url")
            private String absUrl;

            public VideoUrls() {
            }

            VideoUrls(Parcel in) {
                id = in.readInt();
                experiencesId = in.readInt();
                videoUrl = in.readString();
                created = in.readString();
                companyId = in.readInt();
                poster = in.readString();
                status = in.readInt();
                absUrl = in.readString();
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public int getExperiencesId() {
                return experiencesId;
            }

            public void setExperiencesId(int experiencesId) {
                this.experiencesId = experiencesId;
            }

            public String getVideoUrl() {
                return videoUrl;
            }

            public void setVideoUrl(String videoUrl) {
                this.videoUrl = videoUrl;
            }

            public String getCreated() {
                return created;
            }

            public void setCreated(String created) {
                this.created = created;
            }

            public int getCompanyId() {
                return companyId;
            }

            public void setCompanyId(int companyId) {
                this.companyId = companyId;
            }

            public String getPoster() {
                return poster;
            }

            public void setPoster(String poster) {
                this.poster = poster;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public String getAbsUrl() {
                return absUrl;
            }

            public void setAbsUrl(String absUrl) {
                this.absUrl = absUrl;
            }

            @Override
            public int describeContents() {
                return 0;
            }

            @Override
            public void writeToParcel(Parcel dest, int flags) {
                dest.writeInt(id);
                dest.writeInt(experiencesId);
                dest.writeString(videoUrl);
                dest.writeString(created);
                dest.writeInt(companyId);
                dest.writeString(poster);
                dest.writeInt(status);
                dest.writeString(absUrl);
            }
        }

    }

    public static class FuncLevel {

        @SerializedName("id")
        private Integer id;
        @SerializedName("parent_id")
        private Integer parentId;
        @SerializedName("title")
        private String title;
        @SerializedName("status")
        private Integer status;
        @SerializedName("created")
        private String created;
        @SerializedName("modified")
        private String modified;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public Integer getParentId() {
            return parentId;
        }

        public void setParentId(Integer parentId) {
            this.parentId = parentId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public Integer getStatus() {
            return status;
        }

        public void setStatus(Integer status) {
            this.status = status;
        }

        public String getCreated() {
            return created;
        }

        public void setCreated(String created) {
            this.created = created;
        }

        public String getModified() {
            return modified;
        }

        public void setModified(String modified) {
            this.modified = modified;
        }

        @Override
        public String toString() {
            return title;
        }
    }

    public static class Title {

        @SerializedName("id")
        private Integer id;
        @SerializedName("title")
        private String title;
        @SerializedName("func_levels")
        private List<FuncLevel> funcLevels = null;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public List<FuncLevel> getFuncLevels() {
            return funcLevels;
        }

        public void setFuncLevels(List<FuncLevel> funcLevels) {
            this.funcLevels = funcLevels;
        }

        @Override
        public String toString() {
            return title;
        }
    }

    public static class Answer {

        @SerializedName("user_review_id")
        private int userReviewId;
        @SerializedName("id")
        private int id;
        @SerializedName("quickguide_question_option_id")
        private int quickguideQuestionOptionId;
        @SerializedName("note")
        private String note;
        @SerializedName("additional_info")
        private String additionalInfo;
        @SerializedName("modal_title")
        private String modalTitle;
        @SerializedName("question_type")
        private String questionType;
        @SerializedName("title")
        private String title;
        @SerializedName("qqo_title")
        private Object qqoTitle;
        @SerializedName("row_id")
        private long rowId;

        public int getUserReviewId() {
            return userReviewId;
        }

        public void setUserReviewId(int userReviewId) {
            this.userReviewId = userReviewId;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getQuickguideQuestionOptionId() {
            return quickguideQuestionOptionId;
        }

        public void setQuickguideQuestionOptionId(Integer quickguideQuestionOptionId) {
            this.quickguideQuestionOptionId = quickguideQuestionOptionId;
        }

        public String getNote() {
            return note;
        }

        public void setNote(String note) {
            this.note = note;
        }

        public String getAdditionalInfo() {
            return additionalInfo;
        }

        public void setAdditionalInfo(String additionalInfo) {
            this.additionalInfo = additionalInfo;
        }

        public String getModalTitle() {
            return modalTitle;
        }

        public void setModalTitle(String modalTitle) {
            this.modalTitle = modalTitle;
        }

        public String getQuestionType() {
            return questionType;
        }

        public void setQuestionType(String questionType) {
            this.questionType = questionType;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public Object getQqoTitle() {
            return qqoTitle;
        }

        public void setQqoTitle(Object qqoTitle) {
            this.qqoTitle = qqoTitle;
        }

        public long getRowId() {
            return rowId;
        }

        public void setRowId(long rowId) {
            this.rowId = rowId;
        }
    }

    public static class Qa {

        @SerializedName("id")
        private Integer id;
        @SerializedName("title")
        private String title;
        @SerializedName("question_type")
        private String questionType;
        @SerializedName("is_subtitle")
        private Integer isSubtitle;
        @SerializedName("answers")
        private List<Answer> answers = null;
        @SerializedName("sort_order")
        private int sortOrder;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getQuestionType() {
            return questionType;
        }

        public void setQuestionType(String questionType) {
            this.questionType = questionType;
        }

        public Integer getIsSubtitle() {
            return isSubtitle;
        }

        public void setIsSubtitle(Integer isSubtitle) {
            this.isSubtitle = isSubtitle;
        }

        public List<Answer> getAnswers() {
            return answers;
        }

        public void setAnswers(List<Answer> answers) {
            this.answers = answers;
        }

        public int getSortOrder() {
            return sortOrder;
        }

        public void setSortOrder(int sortOrder) {
            this.sortOrder = sortOrder;
        }
    }

    public static class Question implements Serializable {
        @SerializedName("id")
        private int id;
        @SerializedName("title")
        private String title;
        @SerializedName("heading")
        private String heading;
        @SerializedName("question_type")
        private String questionType;
        @SerializedName("add_note")
        private int addNote;
        @SerializedName("info_text")
        private String infoText;
        @SerializedName("button_text")
        private String buttonText;
        @SerializedName("modal_title")
        private String modalTitle;
        @SerializedName("options")
        private List<Option> options;
        @SerializedName("modal")
        private List<Option> modal;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getHeading() {
            return heading;
        }

        public void setHeading(String heading) {
            this.heading = heading;
        }

        public String getQuestionType() {
            return questionType;
        }

        public void setQuestionType(String questionType) {
            this.questionType = questionType;
        }

        public int getAddNote() {
            return addNote;
        }

        public void setAddNote(int addNote) {
            this.addNote = addNote;
        }

        public String getInfoText() {
            return infoText;
        }

        public void setInfoText(String infoText) {
            this.infoText = infoText;
        }

        public String getButtonText() {
            return buttonText;
        }

        public void setButtonText(String buttonText) {
            this.buttonText = buttonText;
        }

        public String getModalTitle() {
            return modalTitle;
        }

        public void setModalTitle(String modalTitle) {
            this.modalTitle = modalTitle;
        }

        public List<Option> getOptions() {
            return options;
        }

        public void setOptions(List<Option> options) {
            this.options = options;
        }

        public List<Option> getModal() {
            return modal;
        }

        public void setModal(List<Option> modal) {
            this.modal = modal;
        }
    }

    public static class Option implements Serializable {
        @SerializedName("title")
        private String title;
        @SerializedName("icon_url")
        private String iconUrl;
        @SerializedName("option_id")
        private int optionId;
        @SerializedName("option_question_id")
        private int optionQuestionId;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getIconUrl() {
            return iconUrl;
        }

        public void setIconUrl(String iconUrl) {
            this.iconUrl = iconUrl;
        }

        public int getOptionId() {
            return optionId;
        }

        public void setOptionId(int optionId) {
            this.optionId = optionId;
        }

        public int getOptionQuestionId() {
            return optionQuestionId;
        }

        public void setOptionQuestionId(int optionQuestionId) {
            this.optionQuestionId = optionQuestionId;
        }
    }

    public static class Competency implements Parcelable, Serializable {
        public static final Creator<Competency> CREATOR = new Creator<Competency>() {
            @Override
            public Competency createFromParcel(Parcel source) {
                return new Competency(source);
            }

            @Override
            public Competency[] newArray(int size) {
                return new Competency[size];
            }
        };
        @SerializedName("id")
        private int id;
        @SerializedName("experience_id")
        private String experienceId;
        @SerializedName("company_id")
        private int companyId;
        @SerializedName("title")
        private String title;
        @SerializedName("icon_url")
        private String iconUrl;
        @SerializedName("sort_order")
        private int sortOrder;
        @SerializedName("status")
        private int status;
        @SerializedName("created")
        private String created;
        @SerializedName("modified")
        private String modified;
        @SerializedName("description")
        private String description;
        @SerializedName("comp_orig_id")
        private int compOrigId;

        public Competency() {
        }

        Competency(Parcel source) {
            this.id = source.readInt();
            this.experienceId = source.readString();
            this.companyId = source.readInt();
            this.title = source.readString();
            this.iconUrl = source.readString();
            this.sortOrder = source.readInt();
            this.status = source.readInt();
            this.created = source.readString();
            this.modified = source.readString();
            this.description = source.readString();
            this.compOrigId = source.readInt();
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getExperienceId() {
            return experienceId;
        }

        public void setExperienceId(String experienceId) {
            this.experienceId = experienceId;
        }

        public int getCompanyId() {
            return companyId;
        }

        public void setCompanyId(int companyId) {
            this.companyId = companyId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getIconUrl() {
            return iconUrl;
        }

        public void setIconUrl(String iconUrl) {
            this.iconUrl = iconUrl;
        }

        public int getSortOrder() {
            return sortOrder;
        }

        public void setSortOrder(int sortOrder) {
            this.sortOrder = sortOrder;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getCreated() {
            return created;
        }

        public void setCreated(String created) {
            this.created = created;
        }

        public String getModified() {
            return modified;
        }

        public void setModified(String modified) {
            this.modified = modified;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public int getCompOrigId() {
            return compOrigId;
        }

        public void setCompOrigId(int compOrigId) {
            this.compOrigId = compOrigId;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(id);
            dest.writeString(experienceId);
            dest.writeInt(companyId);
            dest.writeString(title);
            dest.writeString(iconUrl);
            dest.writeInt(sortOrder);
            dest.writeInt(status);
            dest.writeString(created);
            dest.writeString(modified);
            dest.writeString(description);
            dest.writeInt(compOrigId);
        }
    }

    public static class ReflectionQuestion implements Serializable {
        @SerializedName("status")
        private int status;
        @SerializedName("message")
        private String message;
        @SerializedName("data")
        private Data data;

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Data getData() {
            return data;
        }

        public void setData(Data data) {
            this.data = data;
        }

        public static class Data implements Serializable {
            @SerializedName("questions")
            private List<Question> questions;
            @SerializedName("experiences")
            private ArrayList<Experiences> experiences;
            @SerializedName("competencies")
            private ArrayList<Competency> competencies;

            public List<Question> getQuestions() {
                return questions;
            }

            public void setQuestions(List<Question> questions) {
                this.questions = questions;
            }

            public ArrayList<Experiences> getExperiences() {
                return experiences;
            }

            public void setExperiences(ArrayList<Experiences> experiences) {
                this.experiences = experiences;
            }

            public ArrayList<Competency> getCompetencies() {
                return competencies;
            }

            public void setCompetencies(ArrayList<Competency> competencies) {
                this.competencies = competencies;
            }
        }
    }

    public static class GetAllReflections {
        public int status;
        public String message;
        public List<Reflections> data;

        public static class Reflections {
            public int id;
            public String user_id;
            public String title;
            public String type;
            public String audio_url;
            public String note;
            public boolean is_shared;
            public int status;
            public String created;
            public List<QA> qa;

            public static class QA {
                public int id;
                public String title;
                public String question_type;
                public int is_subtitle;
                public List<Answers> answers;

                public static class Answers {
                    public int user_review_id;
                    public int id;
                    public int quickguide_question_option_id;
                    public String note;
                    public String additional_info;
                    public String modal_title;
                    public String question_type;
                    public String title;
                    public String qqo_title;
                }
            }
        }
    }

    public static class SingleReflection {
        @SerializedName("status")
        private Integer status;
        @SerializedName("message")
        private String message;
        @SerializedName("data")
        private Reflections data = null;

        public Integer getStatus() {
            return status;
        }

        public void setStatus(Integer status) {
            this.status = status;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Reflections getData() {
            return data;
        }

        public void setData(Reflections data) {
            this.data = data;
        }

        public static class Reflections {
            @SerializedName("id")
            private int id;
            @SerializedName("user_id")
            private String userId;
            @SerializedName("title")
            private String title;
            @SerializedName("type")
            private String type;
            @SerializedName("audio_url")
            private String audioUrl;
            @SerializedName("note")
            private String note;
            @SerializedName("is_shared")
            private boolean isShared;
            @SerializedName("status")
            private int status;
            @SerializedName("created")
            private String created;
            @SerializedName("qa")
            private List<Qa> qa;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getUserId() {
                return userId;
            }

            public void setUserId(String userId) {
                this.userId = userId;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getAudioUrl() {
                return audioUrl;
            }

            public void setAudioUrl(String audioUrl) {
                this.audioUrl = audioUrl;
            }

            public String getNote() {
                return note;
            }

            public void setNote(String note) {
                this.note = note;
            }

            public boolean isShared() {
                return isShared;
            }

            public void setShared(boolean shared) {
                isShared = shared;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public String getCreated() {
                return created;
            }

            public void setCreated(String created) {
                this.created = created;
            }

            public List<Qa> getQa() {
                return qa;
            }

            public void setQa(List<Qa> qa) {
                this.qa = qa;
            }
        }
    }

    public static class Analytics {
        @SerializedName("status")
        public int status;
        @SerializedName("message")
        public String message;
        @SerializedName("data")
        public Data data;

        public static class Data {
            @SerializedName("total")
            public List<Total> total;
            @SerializedName("featured")
            public String featured;
            @SerializedName("topmost")
            public Top top;
        }

        public static class Total {
            @SerializedName("cmonth")
            public String currentMonth;
            @SerializedName("pmonth")
            public String previousMonth;
            @SerializedName("cweek")
            public String currentWeek;
            @SerializedName("pweek")
            public String previousWeek;
        }

        public static class Top {
            @SerializedName("ord_data")
            public List<OrderData> data;
            @SerializedName("total")
            public long total;
        }

        public static class OrderData {
            @SerializedName("option_id")
            public String optionId;
            @SerializedName("count")
            public long count;
            @SerializedName("question_id")
            public String questionId;
            @SerializedName("title")
            public String title;
            @SerializedName("icon_url")
            public String iconUrl;
            @SerializedName("opt_id")
            public String optId;
        }
    }

    public static class GetProjectsOrMilestones implements Serializable {
        @SerializedName("status")
        private int status;
        @SerializedName("data")
        private List<ProjectsOrMilestones> data = null;
        @SerializedName("message")
        private String message;

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public List<ProjectsOrMilestones> getData() {
            return data;
        }

        public void setData(List<ProjectsOrMilestones> data) {
            this.data = data;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

    public static class ProjectsOrMilestones implements Serializable {
        @SerializedName("id")
        private int id;
        @SerializedName("title")
        private String title;
        @SerializedName("created")
        private String created;
        @SerializedName("action_ids")
        private List<Integer> actionIds = null;
        @SerializedName("action_title")
        private List<String> actionTitle = null;
        @SerializedName("all_actions")
        private List<Actions> actions = null;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public List<Actions> getActions() {
            return actions;
        }

        public void setActions(List<Actions> actions) {
            this.actions = actions;
        }

        public String getCreated() {
            return created;
        }

        public void setCreated(String created) {
            this.created = created;
        }

        public List<Integer> getActionIds() {
            return actionIds;
        }

        public void setActionIds(List<Integer> actionIds) {
            this.actionIds = actionIds;
        }

        public List<String> getActionTitle() {
            return actionTitle;
        }

        public void setActionTitle(List<String> actionTitle) {
            this.actionTitle = actionTitle;
        }
    }

    public static class GetMilestoneActions implements Serializable {
        @SerializedName("status")
        private int status;
        @SerializedName("data")
        private List<Actions> actions = null;
        @SerializedName("message")
        private String message;

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public List<Actions> getActions() {
            return actions;
        }

        public void setActions(List<Actions> actions) {
            this.actions = actions;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

    }

    public static class GetDevPlans implements Serializable {
        @SerializedName("status")
        private int status;
        @SerializedName("data")
        private List<DevPalns> data = null;
        @SerializedName("message")
        private String message;

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public List<DevPalns> getData() {
            return data;
        }

        public void setData(List<DevPalns> data) {
            this.data = data;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

    public static class DevPalns implements Serializable {
        @SerializedName("id")
        private int id;
        @SerializedName("title")
        private String title;
        @SerializedName("role")
        private String role;
        @SerializedName("milestones")
        private List<Actions> milestones = null;
        @SerializedName("actions")
        private List<Actions> actions = null;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getRole() {
            return role;
        }

        public void setRole(String role) {
            this.role = role;
        }

        public List<Actions> getMilestones() {
            return milestones;
        }

        public void setMilestones(List<Actions> milestones) {
            this.milestones = milestones;
        }

        public List<Actions> getActions() {
            return actions;
        }

        public void setActions(List<Actions> actions) {
            this.actions = actions;
        }

    }

    public static class Actions implements Serializable {
        @SerializedName("id")
        private int id;
        @SerializedName("title")
        private String title;
        @SerializedName("user_milestone_id")
        private int userMilestoneId;
        @SerializedName("end_date")
        private String endDate;
        private Date date;
        @SerializedName("notes")
        private String notes;
        @SerializedName("user_id")
        private String userId;
        @SerializedName("status")
        private int status;
        @SerializedName("created")
        private String created;
        @SerializedName("modified")
        private String modified;
        @SerializedName("liked")
        private int liked;
        @SerializedName("commentcount")
        private int commentcount;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getCreated() {
            return created;
        }

        public void setCreated(String created) {
            this.created = created;
        }

        public String getModified() {
            return modified;
        }

        public void setModified(String modified) {
            this.modified = modified;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public int getLiked() {
            return liked;
        }

        public void setLiked(int like) {
            this.liked = like;
        }

        public int getCommentCount() {
            return commentcount;
        }

        public void setCommentCount(int commentcount) {
            this.commentcount = commentcount;
        }

        public int getUserMilestoneId() {
            return userMilestoneId;
        }

        public void setUserMilestoneId(int userMilestoneId) {
            this.userMilestoneId = userMilestoneId;
        }

        public String getEndDate() {
            return endDate;
        }

        public void setEndDate(String endDate) {
            this.endDate = endDate;
        }

        public Date getDate() {
            return date;
        }

        public void setDate(Date endDate) {
            this.date = endDate;
        }

        public String getNotes() {
            return notes;
        }

        public void setNotes(String notes) {
            this.notes = notes;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

    }

    public static class SingleAnalytics {
        public int status;
        public String message;
        public Data data;

        public static class Data {
            public List<Total> total;
            public List<Stat> stats;
        }

        public static class Total {
            public String count;
        }

        public static class Stat {
            @SerializedName("option_id")
            public String optionId;
            @SerializedName("count")
            public long count;
            @SerializedName("question_id")
            public long questionId;
            @SerializedName("title")
            public String title;
            @SerializedName("icon_url")
            public String iconUrl;
            @SerializedName("type")
            public String type;
        }
    }

    public static class SingleOptionAnalytics {
        public int status;
        public String message;
        public Data data;

        public static class Data {
            public List<Info> info;
            @SerializedName("opt_title")
            public OptionTitle optionTitle;
        }

        public static class Info {
            public String id;
            public String title;
            public String note;
            public String created;
        }

        public static class OptionTitle {
            public String title;
            @SerializedName("icon_url")
            public String iconUrl;
        }
    }

    public static class AnalyticsBody {
        @SerializedName("time")
        public int time;
        @SerializedName("type")
        public String type;
        @SerializedName("exp_id")
        public String expId;
        @SerializedName("comp_id")
        public String compId;
        @SerializedName("user_id")
        public String userId;
        @SerializedName("company_id")
        public String companyId;
        @SerializedName("question_id")
        public int questionId;
        @SerializedName("opt_id")
        public int optId;
        @SerializedName("option_id")
        public int optionId;
        @SerializedName("type_opt")
        String optionType;
        @SerializedName("title")
        String title;
//        @SerializedName("opt_id")
//        public String opt_id;

        public AnalyticsBody(int time, String type, String expId, String compId, String userId, String companyId) {
            this.time = time;
            this.type = type;
            this.expId = expId;
            this.compId = compId;
            this.userId = userId;
            this.companyId = companyId;
        }

        public AnalyticsBody(int time, String type, String expId, String compId, String userId, String companyId, int questionId, int optId) {
            this.time = time;
            this.type = type;
            this.expId = expId;
            this.compId = compId;
            this.userId = userId;
            this.companyId = companyId;
            this.questionId = questionId;
            this.optId = optId;
        }

        public AnalyticsBody(int time, String type, String expId, String compId, String userId, String companyId, int questionId, int optionId, String optionType, String title, int optId) {
            this.time = time;
            this.type = type;
            this.expId = expId;
            this.compId = compId;
            this.userId = userId;
            this.companyId = companyId;
            this.questionId = questionId;
            this.optionId = optionId;
            this.optionType = optionType;
            this.title = title;
            this.optId = optId;
        }
    }

    public static class SingleReflectionBody {
        public long[] ids;
        public String answers;
        @SerializedName("question_type")
        public String questionType;
        @SerializedName("title_update")
        public int titleUpdate;
        public String created;

        public SingleReflectionBody(long[] ids, String answers, String questionType, String createdDate) {
            this.ids = ids;
            this.answers = answers;
            this.questionType = questionType;
            titleUpdate = 1;
            this.created = createdDate;
        }
    }

    public static class GetComments {
        @SerializedName("status")
        private int status;
        @SerializedName("data")
        private CommentsData data;
        @SerializedName("message")
        private String message;

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public CommentsData getData() {
            return data;
        }

        public void setData(CommentsData data) {
            this.data = data;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

    public static class CommentsData {
        @SerializedName("comments")
        private List<Comment> comments = null;
        @SerializedName("line_manager")
        private LineManager lineManager;

        public List<Comment> getComments() {
            return comments;
        }

        public void setComments(List<Comment> comments) {
            this.comments = comments;
        }

        public LineManager getLineManager() {
            return lineManager;
        }

        public void setLineManager(LineManager lineManager) {
            this.lineManager = lineManager;
        }
    }

    public static class Comment {
        @SerializedName("user_id")
        private String userId;
        @SerializedName("tag")
        private String tag;
        @SerializedName("item_id")
        private int itemId;
        @SerializedName("text")
        private String text;
        @SerializedName("image_url")
        private String imageUrl;
        @SerializedName("created")
        private String created;


        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getTag() {
            return tag;
        }

        public void setTag(String tag) {
            this.tag = tag;
        }

        public int getItemId() {
            return itemId;
        }

        public void setItemId(int itemId) {
            this.itemId = itemId;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public String getImageUrl() {
            return imageUrl;
        }

        public void setImageUrl(String imageUrl) {
            this.imageUrl = imageUrl;
        }

        public String getCreated() {
            return created;
        }

        public void setCreated(String created) {
            this.created = created;
        }

    }

    public static class LineManager {

        @SerializedName("display_name")
        private String displayName;
        @SerializedName("image_url")
        private String imageUrl;

        public String getDisplayName() {
            return displayName;
        }

        public void setDisplayName(String displayName) {
            this.displayName = displayName;
        }

        public String getImageUrl() {
            return imageUrl;
        }

        public void setImageUrl(String imageUrl) {
            this.imageUrl = imageUrl;
        }
    }

    public class GetFullCompetencyList {
        public int status;
        public String message;
        public List<Comptency> data;

        public class Comptency {
            public int id;
            public String title;
            public String icon_url;
            public int comp_orig_id;
        }
    }

    public class GetLeadershipExperience {
        public int status;
        public String message;
        public List<LeadershipExperience> data;

        public class LeadershipExperience {
            public int id;
            public String title;
            public String icon_url;
            public int company_id;
            public int exp_id;
        }
    }
}


