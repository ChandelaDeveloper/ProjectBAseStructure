package com.example.amit.parshant.localtravelguid.mvvp.views;

import retrofit2.Response;

/**
 * Created by signity on 7/9/17.
 */

public interface BaseView {

    /**
     * is called when public void onFailure(Call<RetroResponse.LoginResponse> call, Throwable t)
     */
    void onRetroRequestFailure();

    /**
     * When retrofit returns in onSuccess(Response<?> response) and response is not successful
     * @param response
     */
    void onError(Response<?> response);

    /**
     * If internet is not present show error dialog here
     */
    void showNoInternetDialog();

    /**
     * Show loader when required
     */
    void showLoadingDialog();
    /**
     * Show loader when required
     * to show custom message
     */
    void showLoadingDialog(String msg);

    /**
     * Hide loading dialog
     */
    void hideLoadingDialog();

}
