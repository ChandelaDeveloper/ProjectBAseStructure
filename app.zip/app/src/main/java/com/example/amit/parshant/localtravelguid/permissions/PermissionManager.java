package com.example.amit.parshant.localtravelguid.permissions;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dev on 27/1/17.
 */

public final class PermissionManager {
    public static final int REQUEST_ROBI_PREMISSION = 1;
    public static final int RESULT_SETTINGS = 1000;

    private static PermissionManager instance;

    private List<String> permissions;
    private OnPermissionRequestedCallback callback;

    private PermissionManager() {
        permissions = new ArrayList<>();
    }

    public static PermissionManager getInstance() {
        if (instance == null)
            instance = new PermissionManager();
        return instance;
    }

    public boolean isPermissionRequired(Activity activity, String[] permissions) {
        boolean required = false;
        this.permissions.clear();
        for (String permission : permissions) {
            if (ActivityCompat.checkSelfPermission(activity, permission) != PackageManager.PERMISSION_GRANTED) {
                this.permissions.add(permission);
                required = true;
            }
        }
        return required;
    }

    public boolean shouldShowRequestPermissionRationale(Activity activity, String permission) {
        return ActivityCompat.shouldShowRequestPermissionRationale(activity, permission);
    }

    public void requestPermission(Activity activity, int requestCode, OnPermissionRequestedCallback callback) {
        this.callback = callback;
        ActivityCompat.requestPermissions(activity, permissions.toArray(new String[permissions.size()]), requestCode);
    }

    public void requestPermission(Fragment fragment, int requestCode, OnPermissionRequestedCallback callback) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            this.callback = callback;
            fragment.requestPermissions(permissions.toArray(new String[permissions.size()]), requestCode);
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (grantResults.length > 0) {
            int length = grantResults.length;
            int granted = 0;
            List<String> revoked = new ArrayList<>();
            for (int i = 0; i < length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED)
                    granted++;
                else
                    revoked.add(permissions[i]);
            }
            if (granted == length) {
                if (callback != null)
                    callback.onPermissionGranted(requestCode);
            } else {
                if (callback != null)
                    callback.onPermissionRevoked(requestCode, revoked);
            }
        }
    }

    public void openSettings(Context context) {
        Intent in = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        in.setData(Uri.fromParts("package", context.getPackageName(), null));
        in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(in);
    }
}