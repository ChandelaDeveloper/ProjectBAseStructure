package com.example.amit.parshant.localtravelguid.utils;

/**
 * Created by signity on 14/11/17.
 */

public class Constants {

    public static final String DUMMY_PIC_URL = "https://image.ibb.co/jPxiAn/ic_profile_dumy.png";


    public static final String USER_EMAIL = "user_email";
    public static final String USER_NUMBER = "user_number";
    public static final String IN_PROGRESS = "inProgress";
    public static final String JOB_ID = "job_id";
    public static final String SERVICE_ID = "service_id";
    public static final String NOTIFICATION = "notification";
    static final String SHARED_PREFRANCES_NAME = "talupp";
    public static final String LANGUAGE_TYPE = "lang";
    public static final String USER_ID = "user_id";
    public static final String VIDEO_DATA = "video_data";
    public static final String USER_IMAGE = "user_image";
    public static final String USER_NAME = "user_name";
    public static final String NOTIFICATION_SOUND = "notification sound";
    public static final String NOTIFICATION_STATUS = "notification status";
    public static final String COMPANY_ID = "company_id";
    public static final String USER_ROLE = "user_role";
    public static final String SLID_ACCESS_ROUTES = "access_routes";
    public static final String USER_LOGIN_STATE = "login_state";
    public static final String API_TOKEN = "api_token";
    public static final String REQ_STATE = "requested_state";
    public static final String Data = "data";
    public static final String RESULT = "result";
    public static final String DELETE_PHOTO = "delete_pic";

    public static final String DATE_SD = "_sd";
    public static final String DATE_LA = "_la";
    public static final String DATE_RR = "_rr";
    public static  String Fragment_POSITION = "0";

    public static final String DASHBOARD_DEV_PLAN="dev";
    public static final String MY_LIBRARY="ml";
    public static final String WHAT_EXPERIENCE_MATTERS="em";
    public static final String L_O_T_G="lotg";
    public static final String LEDERSHIP_EXPERENCE="le";



    public static final String FCM_ID = "fcmId";
    public static final String DEV_ID = "dev_id";
    public static final String USER_CRNT_ROLE_STATUS ="current_role" ;
    public static final String LOGIN ="login" ;
    public static final String LOGOUT ="logout" ;
    public static final String ROLE = "role";
    public static final String CAME_FROM ="came_from" ;
    public static final String EXP_OBJ ="exp_obj" ;
    public static final String EXP_ID ="exp_id" ;
    public static final String ICON = "icon";
    public static final String TITLE = "title";
    public static final String DESCRIPTION ="description" ;
    public static final String SELECTED_PROJECT ="selected_project" ;
    public static final String VIDEO_URL = "url";
    public static final String YES = "Yes";
    public static final String NO = "NO";
    public static final String HIDE_FIRST_LOTG = "first_lotg_holder";
    public static final String HIDE_SECOND_LOTG = "second_lotg_holder";

    public static final String HIDE_FIRST_LE = "first_le_holder";
    public static final String HIDE_SECOND_LE = "second_le_holder";

    public static final String DEV_PLAN ="dev_plan" ;
    public static final String MILESTONE ="milestone" ;
    public static final String MILESTONE_ID ="milestone_id" ;
    public static final String ACTION_SELECTED ="selected_action" ;
    public static final String HIDE_FIRST_DEV_PLAN = "first_dev_holder";
    public static final String HIDE_SECOND_DEV_PLAN = "second_dev_holder";
    public static final String DEVELOPMENT_PLAN = "development_plans";
    public static final String ABS_URL = "abs_url";
    public static final String ACTION_LIST ="action" ;
    public static final String ACTION ="action" ;
    public static final String ANDROID = "android";
    public static final int MILESTONE_ACTION_COMPLETED = 2;
    public static final String ID ="id" ;
    public static int CURRENT_ROLE_NOT_ADDED=0;
    public static int CURRENT_ROLE_ALREADY_ADDED=1;

    public static final String VIDEO_SERIALIZABLE = "videoUrl";
    public static final String DOWNLOAD_KEY= "downloadUrl";
    public static final String LIKED_VIDEO_SERILIZABLE = "likedVideo";

    public static final int VIDEO_LIKE_REQUEST_CODE= 10;
    public static final int VIDEO_SORT_REQUEST_CODE= 11;
    public static final int VIDEO_SORT_ORDER_REQUEST_CODE= 12;

    public static final int WHAT_EXPERIENCE_MATTER_SELECTION = 4;
    public static final int EXPERIENCE_PROFILE_SELECTION = 1;
    public static final int LIBRARY_SELECTION = 5;
    public static final int ON_GO_SELECTION = 3;
    public static final int DEV_PLANS_SELECTION = 2;
    public static final int DASHBOARD_SELECTION = 0;
    public static final int EXPLORE_SELECTION = 6;

    public static final int CURRENT_ROLE = 1;
    public static final int TEMP_ASSG = 2;
    public static final int WORKPLACE = 3;

    public static final String AWS_ACCESS_KEY = "AKIAJ73BYAJJENUEZ7SA";
    public static final String AWS_SECRET_KEY = "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";
    public static final String AWS_BUCKET_NAME = "staging-talupp";
//    public static final String BUCKET_REGION = "eu-west-2";
    public static final String AWS_ENDPOINT = "https://s3.eu-west-2.amazonaws.com/staging-talupp/";

}
