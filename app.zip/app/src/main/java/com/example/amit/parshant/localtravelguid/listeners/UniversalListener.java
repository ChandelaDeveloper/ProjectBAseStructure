package com.example.amit.parshant.localtravelguid.listeners;

/**
 * Created by parshant on 20/2/18.
 */

public class UniversalListener<T> {


    private static UniversalListener instance;
    private static Object lock = new Object();
    private Watcher<T> listener;

    private UniversalListener() {
    }

    public static UniversalListener getInstance() {

        if (instance == null) {
            synchronized (lock) {
                instance = new UniversalListener();
            }
        }

        return instance;
    }

    public void register(Watcher<T> listener) {
        this.listener = listener;
    }

    public void unregister() {
        listener = null;
    }

    public void update(T data, int position) {
        if (listener != null) {
            listener.update(data, position);
        }
    }

    public interface Watcher<T> {
        void update(T data, int position);
        void add(T data);
    }

}
