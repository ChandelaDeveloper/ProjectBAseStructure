package com.example.amit.parshant.localtravelguid.mvvp.interacted;

import retrofit2.Response;

/**
 * Created by signity on 7/9/17.
 */

public interface OnBaseInteractedListener {

    void onRetroRequestFailure();

    void showNoInternetDialog();

    void showLoadingDialog();

    void hideLoadingDialog();

    void onError(Response<?> response);
}
