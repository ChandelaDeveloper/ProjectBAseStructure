package com.example.amit.parshant.localtravelguid.utils.customViews;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

import com.example.amit.parshant.localtravelguid.R;


/**
 * Created by signity on 29/11/17.
 */

public class DashLineView extends View {
    private static final String TAG = DashLineView.class.getSimpleName();

    private static final int DEFAULT_DASH_WIDTH = 4;
    private static final int DEFAULT_LINE_WIDTH = 4;
    private static final int DEFAULT_LINE_HEIGHT = 2;
    private static final int DEFAULT_LINE_SELECTED_COLOR = 0xff888888;
    private static final int DEFAULT_LINE_DISABLED_COLOR = 0xff888888;
    private static final int DEFAULT_LINE_DIVIDER = 1;

    private static final int ORIENTATION_HORIZONTAL = 0;
    private static final int ORIENTATION_VERTICAL = 1;
    private static final int DEFAULT_DASH_ORIENTATION = ORIENTATION_HORIZONTAL;
    private float dashWidth = DEFAULT_DASH_WIDTH;
    private float lineWidth = DEFAULT_LINE_WIDTH;
    private float lineHeight = DEFAULT_LINE_HEIGHT;
    private int lineSelectedColor = DEFAULT_LINE_SELECTED_COLOR;
    private int lineDisabledColor = DEFAULT_LINE_DISABLED_COLOR;
    private int lineDivider = DEFAULT_LINE_DIVIDER;
    private int dashOrientation;
    private int selectedIndex = 0;

    private Paint mPaint;
    private int widthSize;
    private int heightSize;

    public DashLineView(Context context) {
        this(context, null);
    }

    public DashLineView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public DashLineView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mPaint = new Paint(1);
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.DashLineView);
        dashWidth = typedArray.getDimension(R.styleable.DashLineView_dashWidth, DEFAULT_DASH_WIDTH);
        lineWidth = typedArray.getDimension(R.styleable.DashLineView_lineWidth, DEFAULT_LINE_WIDTH);
        lineHeight = typedArray.getDimension(R.styleable.DashLineView_lineHeight, DEFAULT_LINE_HEIGHT);
        lineSelectedColor = typedArray.getColor(R.styleable.DashLineView_lineSelectedColor, DEFAULT_LINE_SELECTED_COLOR);
        lineDisabledColor = typedArray.getColor(R.styleable.DashLineView_lineDisabledColor, DEFAULT_LINE_DISABLED_COLOR);
        dashOrientation = typedArray.getInteger(R.styleable.DashLineView_dashOrientation, DEFAULT_DASH_ORIENTATION);
        lineDivider = typedArray.getInteger(R.styleable.DashLineView_divideLineBy, DEFAULT_LINE_DIVIDER);
        mPaint.setColor(lineSelectedColor);
        mPaint.setStrokeWidth(lineHeight);
        typedArray.recycle();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        widthSize = MeasureSpec.getSize(widthMeasureSpec) - getPaddingLeft() - getPaddingRight();
        heightSize = MeasureSpec.getSize(heightMeasureSpec - getPaddingTop() - getPaddingBottom());
        lineWidth = (widthSize - (dashWidth * lineDivider)) / lineDivider;
        if (dashOrientation == ORIENTATION_HORIZONTAL) {
            setMeasuredDimension(widthSize, (int) lineHeight);
        } else {
            setMeasuredDimension((int) lineHeight, heightSize);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        switch (dashOrientation) {
            case ORIENTATION_VERTICAL:
                drawVerticalLine(canvas);
                break;
            default:
                drawHorizontalLine(canvas);
        }
    }

    private void drawHorizontalLine(Canvas canvas) {
        float totalWidth = 0;
        canvas.save();
        float[] pts = {0, 0, lineWidth, 0};
        canvas.translate(0, lineHeight / 2);
        int i = 1;
        while (totalWidth <= widthSize) {
            mPaint.setColor(i <= selectedIndex ? lineSelectedColor : lineDisabledColor);
            canvas.drawLines(pts, mPaint);
            canvas.translate(lineWidth + dashWidth, 0);
            totalWidth += lineWidth + dashWidth;
            i++;
        }
        canvas.restore();
    }

    private void drawVerticalLine(Canvas canvas) {
        float totalWidth = 0;
        canvas.save();
        float[] pts = {0, 0, 0, lineWidth};
        canvas.translate(lineHeight / 2, 0);
        int i = 1;
        while (totalWidth <= heightSize) {
            mPaint.setColor(i <= selectedIndex ? lineSelectedColor : lineDisabledColor);
            canvas.drawLines(pts, mPaint);
            canvas.translate(0, lineWidth + dashWidth);
            totalWidth += lineWidth + dashWidth;
            i++;
        }
        canvas.restore();
    }

    public void setSelectedIndex(int index) {
        selectedIndex = index > lineDivider ? lineDivider : index;
        invalidate();
    }

    public void setLineDivider(int divider) {
        lineDivider = divider;
        requestLayout();
    }

    public int getLineDivider() {
        return lineDivider;
    }
}