package com.example.amit.parshant.localtravelguid.utils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.View;

import com.example.amit.parshant.localtravelguid.R;


/**
 * Created by signity on 22/12/17.
 */

public class SwipeHelper extends ItemTouchHelper.SimpleCallback {
    private RecyclerSwipeListener listener;
    private ColorDrawable background;
    private int backgroundColor = Color.parseColor("#f44336");
    private Drawable deleteIcon;
    private int intrinsicWidth;
    private int intrinsicHeight;

    public SwipeHelper(Context context, RecyclerSwipeListener listener) {
        super(0, ItemTouchHelper.LEFT);
        this.listener = listener;
        background = new ColorDrawable();
        deleteIcon = ContextCompat.getDrawable(context, android.R.drawable.ic_delete);
        intrinsicWidth = deleteIcon.getIntrinsicWidth();
        intrinsicHeight = deleteIcon.getIntrinsicHeight();
    }

    @Override
    public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
        return false;
    }

    @Override
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
        if (listener != null)
            listener.onSwiped(viewHolder, direction, viewHolder.getAdapterPosition());
    }

    @Override
    public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
        if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {
            View view = viewHolder.itemView;
            int viewHeight = view.getBottom() - view.getTop();
            background.setColor(backgroundColor);
            background.setBounds((int) (view.getRight() + dX), view.getTop(), view.getRight(), view.getBottom());
            background.draw(c);
            int deleteIconTop = view.getTop() + (viewHeight - intrinsicHeight) / 2;
            int deleteIconMargin = (viewHeight - intrinsicHeight) / 2;
            int deleteIconLeft = view.getRight() - deleteIconMargin - intrinsicWidth;
            int deleteIconRight = view.getRight() - deleteIconMargin;
            int deleteIconBottom = deleteIconTop + intrinsicHeight;
            deleteIcon.setBounds(deleteIconLeft, deleteIconTop, deleteIconRight, deleteIconBottom);
            deleteIcon.draw(c);
        }
        super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
    }

    public interface RecyclerSwipeListener {
        void onSwiped(RecyclerView.ViewHolder viewHolder, int direction, int position);
    }
}