package com.example.amit.parshant.localtravelguid.mvvp.presenter;



import com.example.amit.parshant.localtravelguid.mvvp.interacted.OnBaseInteractedListener;
import com.example.amit.parshant.localtravelguid.mvvp.views.BaseView;

import retrofit2.Response;

/**
 * Created by signity on 7/9/17.
 */

public class BasePresenter implements OnBaseInteractedListener {

    BaseView baseView;

    public BasePresenter(BaseView baseView) {
        this.baseView = baseView;
    }


    @Override
    public void onRetroRequestFailure() {
        baseView.onRetroRequestFailure();
    }

    @Override
    public void showNoInternetDialog() {
        baseView.showNoInternetDialog();
    }

    @Override
    public void showLoadingDialog() {
        baseView.showLoadingDialog();
    }

    @Override
    public void hideLoadingDialog() {
        baseView.hideLoadingDialog();
    }

    @Override
    public void onError(Response<?> response) {
        baseView.onError(response);
    }
}
