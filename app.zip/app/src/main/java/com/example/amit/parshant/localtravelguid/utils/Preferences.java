package com.example.amit.parshant.localtravelguid.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by signity on 13/11/17.
 */

public class Preferences {
    private static Preferences preferences;
    private final SharedPreferences sharedPreferences;
    private final SharedPreferences.Editor editor;

    public Preferences(Context context) {
        sharedPreferences = context.getSharedPreferences(Constants.SHARED_PREFRANCES_NAME, context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public static Preferences getInstance(Context context) {
        if (preferences == null) {
            preferences = new Preferences(context);
        }
        return preferences;
    }

    public void setValue(String key, String value) {
        editor.putString(key, value);
        editor.commit();
    }

    public void setValue(String key, int value) {
        editor.putInt(key, value);
        editor.commit();
    }

    public void setValue(String key, boolean value) {
        editor.putBoolean(key, value);
        editor.commit();
    }

    public void setValue(String key, long value) {
        editor.putLong(key, value);
        editor.commit();
    }

    public String getValue(String key, String defaultValue) {
        String st_value = sharedPreferences.getString(key, defaultValue);
        return st_value;
    }

    public int getValue(String key, int defaultValue) {
        int st_value = sharedPreferences.getInt(key, defaultValue);
        return st_value;
    }

    public long getValue(String key, long defaultValue) {
        long st_value = sharedPreferences.getLong(key, defaultValue);
        return st_value;
    }

    public boolean getValue(String key, boolean defaultValue) {
        return sharedPreferences.getBoolean(key, defaultValue);
    }

    public void clearValues() {
        editor.clear();
        editor.commit();
    }


    public void clearCertainValue(String key) {
        editor.remove(key);
        editor.apply();
    }

}
