package com.example.amit.parshant.localtravelguid.utils.validation;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by JSN on 12/9/17.
 */

public abstract class BaseValidation implements IValidator {

    protected List<IValueValidator> validators = new ArrayList<>();

    protected boolean allValidated(String value) {
        for (IValueValidator validator : validators) {
            boolean result = validator.validate(value);

            if (!result) {
                setError(validator.getErrorMsg());
                return false;
            }
        }
        return true;
    }

    protected void warnFieldRequired() {
        setError("This field is required!");
    }

    public void add(IValueValidator validator) {
        validators.add(validator);
    }


}
