package com.example.amit.parshant.localtravelguid.servercall;

import com.example.amit.parshant.localtravelguid.activities.BaseActivity;
import com.example.amit.parshant.localtravelguid.utils.Constants;
import com.example.amit.parshant.localtravelguid.utils.Preferences;
import com.example.amit.parshant.localtravelguid.utils.ServerURL;

import java.io.IOException;
import java.util.concurrent.TimeUnit;


import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by signity on 14/11/17.
 */

public class ServerApiClient {

    public static TaluppInterface taluppInterface;

    public static TaluppInterface getRetroInstance() {
        if (taluppInterface == null) {
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BODY);

            OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
            httpClient.networkInterceptors().add(new Interceptor() {
                @Override
                public Response intercept(Interceptor.Chain chain) throws IOException {
                    Request original = chain.request();

                    Request request = original.newBuilder()
                            .header("token", Preferences.getInstance(BaseActivity.sContext).getValue(Constants.API_TOKEN, ""))
                            .header("device-type", Constants.ANDROID)
                            .method(original.method(), original.body())
                            .build();

                    return chain.proceed(request);
                }
            });
            httpClient.addInterceptor(logging);
//            httpClient.addInterceptor(new RetrofitInterceptor());
            httpClient.readTimeout(2 * 60, TimeUnit.SECONDS);
            httpClient.writeTimeout(2 * 60, TimeUnit.SECONDS);
            httpClient.authenticator(new RetrofitAuthenticator());

            OkHttpClient client = httpClient.build();

            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(ServerURL.BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create())

                    .build();

            taluppInterface = retrofit.create(TaluppInterface.class);
        }
        return taluppInterface;
    }

    public static TaluppInterface getRetroInstance1() {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.networkInterceptors().add(new Interceptor() {
            @Override
            public Response intercept(Interceptor.Chain chain) throws IOException {
                Request original = chain.request();

                Request request = original.newBuilder()
                        .header("token", Preferences.getInstance(BaseActivity.sContext).getValue(Constants.API_TOKEN, ""))
                        .method(original.method(), original.body())
                        .build();

                return chain.proceed(request);
            }
        });
        httpClient.addInterceptor(logging);
//            httpClient.addInterceptor(new RetrofitInterceptor());
        httpClient.readTimeout(2 * 60, TimeUnit.SECONDS);
        httpClient.writeTimeout(2 * 60, TimeUnit.SECONDS);
        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ServerURL.BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        TaluppInterface taluppInterface = retrofit.create(TaluppInterface.class);
        return taluppInterface;
    }

    public static Retrofit retrofit() {

        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

// OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
// httpClient.networkInterceptors().add(new MyOkHttpInterceptor());


        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.networkInterceptors().add(new Interceptor() {
            @Override
            public Response intercept(Interceptor.Chain chain) throws IOException {
                Request original = chain.request();

                Request request = original.newBuilder()
                        .method(original.method(), original.body())
                        .build();

                return chain.proceed(request);
            }
        });
        httpClient.addInterceptor(logging);
        httpClient.readTimeout(2 * 60, TimeUnit.SECONDS);
        httpClient.writeTimeout(2 * 60, TimeUnit.SECONDS);
        OkHttpClient client = httpClient.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ServerURL.BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit;
    }
}
