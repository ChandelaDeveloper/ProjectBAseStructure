package com.example.amit.parshant.localtravelguid.utils.validation;

import android.widget.EditText;

import java.util.regex.Pattern;

/**
 * Created by JSN on 12/9/17.
 */

public class RegexValidation extends BaseValidation {

    private String regularExpression;
    private EditText editText;

//    List<IValueValidator> validators = new ArrayList<>();

    //regular expresssion for email
    private static final String EMAIL_PATTERN = "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";

    private static final String NUMBER_PATTERN = "([0-9]{8,10})";
    public static final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[a-z])|(?=.*[!@#$%^&*+=?-]).{6,16}$";
    public static final String OTP_PATTERN = "";

    public RegexValidation(String regularExpression, EditText editText) {
        this.regularExpression = regularExpression;
        this.editText = editText;
    }

    public RegexValidation(EditText editText) {
        this.editText = editText;
    }

    @Override
    public boolean validate() {
        String value = editText.getText().toString();

        if (StringUtils.invalidString(value)) {
            warnFieldRequired();
            return false;
        }

        if ((!validPattern(EMAIL_PATTERN, value) && !validPattern(NUMBER_PATTERN, value)) && !validPattern(regularExpression, value)) {
           if(errorMsg != null) {
               setError(errorMsg);
           }else{
               setError("wrong value!");
           }
            return false;
        }
        return allValidated(value);
    }

    private boolean validPattern(String expression, String value) {
        return StringUtils.validString(expression) && Pattern.compile(expression).matcher(value).matches();
    }

    @Override
    public void setError(String msg) {
        editText.setError(msg);
    }

    private String errorMsg = null;
    public RegexValidation setErrorMsg(String errorMsg){
        this.errorMsg=errorMsg;
        return this;
    }



}
