package com.example.amit.parshant.localtravelguid.activities;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.amit.parshant.localtravelguid.R;
import com.example.amit.parshant.localtravelguid.fragments.BaseFragment;
import com.example.amit.parshant.localtravelguid.mvvp.views.BaseView;
import com.example.amit.parshant.localtravelguid.permissions.OnPermissionRequestedCallback;
import com.example.amit.parshant.localtravelguid.permissions.PermissionManager;
import com.example.amit.parshant.localtravelguid.servercall.ErrorUtils;
import com.example.amit.parshant.localtravelguid.utils.validation.IValidator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import retrofit2.Response;

/**
 * Created by signity on 13/11/17.
 */

public abstract class BaseActivity extends AppCompatActivity implements BaseView {

    protected static final String DATA = "data";
    private static final String CHECK_INTERNET = "Please check your internet connection";
    private static final int REQUEST_ACTIVITY = 1200;
    public static Context sContext;
    private static BaseActivity baseActivity;
    public int mScreenwidth, mScreenheight;
    HashMap<String, BaseFragment> mStack = new HashMap<>();
    private ClickHandler clickHandler;
    private AlertDialog alertDialog, infoAlertDialog;
    private List<IValidator> validations = new ArrayList<>();
    private ProgressDialog progressDialog;

    public static BaseActivity getInstance() {
        return baseActivity;
    }

    @Override
    protected void onStart() {
        super.onStart();
        sContext = getApplicationContext();
    }

    /**
     * Overriden method of Activity; use in implemented class as a substitute of onCreate
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        baseActivity = this;
        setContentView(getLayoutResID());
        getScreenDimens();
        initUI();
        initListeners();
    }

    /**
     * Screen dimensions in pixels;
     */
    public void getScreenDimens() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        mScreenwidth = displayMetrics.widthPixels;
        mScreenheight = displayMetrics.heightPixels;
    }

    /**
     * resource id of layout like R.id..
     *
     * @return id of the resource mentioned
     */
    protected abstract int getLayoutResID();

    /**
     * initiate the UI elements here
     */
    protected abstract void initUI();

    /**
     * initialize listeners like onClick, onItemClick, etc here
     */
    protected abstract void initListeners();

//    protected abstract void serverCall(int index);

    /**
     * is called when :public void onFailure(Call<RetroResponse.LoginResponse> call, Throwable t)
     */
    @Override
    public void onRetroRequestFailure() {
        infoAlertDialog(CHECK_INTERNET);
    }

    /**
     * When retrofit returns in onSuccess(Response<?> response) and response is not successful
     *
     * @param response
     */
    @Override
    public void onError(Response<?> response) {
        ErrorUtils.APIError error = ErrorUtils.parseError(response);
        if (TextUtils.isEmpty(error.message()))
            infoAlertDialog("Error connecting server!");
        else {
//            if (error.status() == 111) {
//                //TODO: refresh token
//            } else
            infoAlertDialog(error.message());
        }
    }

    /**
     * If internet is not present show error dialog here
     */
    @Override
    public void showNoInternetDialog() {
        infoAlertDialog(CHECK_INTERNET);
    }

    /**
     * Show loader when required
     */
    @Override
    public void showLoadingDialog() {

        if (progressDialog == null) {
            setProgressDialog(getString(R.string.processing));
        }
        try {
            progressDialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Show loader when required with custom message
     */
    @Override
    public void showLoadingDialog(String msg) {

        if (progressDialog == null) {
            setProgressDialog(msg);
        }
        try {
            progressDialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * initialise progress dialog
     *
     * @param msg :hold message to show
     */
    private void setProgressDialog(String msg) {
        try {
            progressDialog = new ProgressDialog(this);
            progressDialog.setCancelable(false);
            progressDialog.setMessage(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Hide loading dialog
     */
    @Override
    public void hideLoadingDialog() {
        try {
            if (progressDialog != null && progressDialog.isShowing()) {
                progressDialog.dismiss();
                progressDialog = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * Validate form fields
     */
    public boolean validateForm() {
        boolean finalResult = true;
        for (IValidator validator : validations) {
            boolean result = validator.validate();
            if (!result) {
                finalResult = false;
            }
        }
        return finalResult;
    }

    /**
     * Add validator over a field
     */
    public void addValidator(IValidator validator) {
        validations.add(validator);
    }

    /**
     * Use to show info message as a pop up
     *
     * @param message : hold info to display
     */
    public void infoAlertDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AlertDialogStyle);
        builder.setMessage(message);
        builder.setCancelable(false);
        builder.setTitle(R.string.app_name);
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (clickHandler != null) clickHandler.onPositiveClick();
                dialog.dismiss();
            }
        });

        infoAlertDialog = builder.create();
        infoAlertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (infoAlertDialog.isShowing())
            infoAlertDialog.dismiss();
        setDialogButtonTextColor(infoAlertDialog);
        infoAlertDialog.show();
    }



    /**
     * Use to set dialog button text color to required color
     * @param alertDialog
     */
    void setDialogButtonTextColor(final AlertDialog alertDialog)
    {
        //  setup to change color of the button
        alertDialog.setOnShowListener( new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface arg0) {
                alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(getResources().getColor(R.color.appColor));
                alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.appColor));
            }
        });
    }

    /**
     * Use to show info message as a pop up
     *
     * @param message : hold info to display
     * @param title   : to display required title
     */
    public void infoAlertDialog(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AlertDialogStyle);
        builder.setMessage(message);
        builder.setCancelable(false);
        builder.setTitle(title);
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (clickHandler != null) clickHandler.onPositiveClick();
                dialog.dismiss();
            }
        });

        infoAlertDialog = builder.create();
        infoAlertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (infoAlertDialog.isShowing())
            infoAlertDialog.dismiss();
        setDialogButtonTextColor(infoAlertDialog);
        infoAlertDialog.show();
    }

    /**
     * To show message and ask for user confirmation
     *
     * @param message  :hold info message text
     * @param positive :to show positive button text on dialog
     * @param negative :to show negative button text on dialog
     */
    public void confirmationAlertDialog(String message, String positive, String negative) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AlertDialogStyle);
        builder.setMessage(message);
        builder.setCancelable(false);
        builder.setTitle(R.string.app_name);

        builder.setPositiveButton( positive
                , new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (clickHandler != null) clickHandler.onPositiveClick();
                        dialog.dismiss();
                    }
                });
        builder.setNegativeButton(negative , new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (clickHandler != null) clickHandler.onNegativeClick();
                dialog.dismiss();
            }
        });

        alertDialog = builder.create();
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (alertDialog.isShowing())
            alertDialog.dismiss();
        setDialogButtonTextColor(alertDialog);
        alertDialog.show();
    }

    /**
     * To show message and ask for user confirmation
     *
     * @param message  :hold info message text
     * @param positive :to show positive button text on dialog
     * @param negative :to show negative button text on dialog
     * @param title    :to display requied title
     */
    public void confirmationAlertDialog(String title, String message, String positive, String negative) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AlertDialogStyle);
        builder.setMessage(message);
        builder.setCancelable(false);
        builder.setTitle(title);

        builder.setPositiveButton( positive
                , new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (clickHandler != null) clickHandler.onPositiveClick();
                        dialog.dismiss();
                    }
                });
        builder.setNegativeButton( negative , new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (clickHandler != null) clickHandler.onNegativeClick();
                dialog.dismiss();
            }
        });

        alertDialog = builder.create();
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (alertDialog.isShowing())
            alertDialog.dismiss();
        setDialogButtonTextColor(alertDialog);
        alertDialog.show();
    }

    /**
     * use to set click handler on dialog button
     *
     * @param click : interface reference that implemented by any class(Activity/Fragment)
     */
    public void setDialogClick(ClickHandler click) {
        clickHandler = click;
    }

    /**
     * To show toast messages in app
     *
     * @param msg : hold message info
     */

    public void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    public void showLongToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

   /* *//**
     * Use to transfer user to login screen
     *
     * @param flag :flag for intent
     */
    public void navigateToLogin(int flag) {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(flag);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    /**
     * Use to transfer user to next screen
     *
     * @param current: current activity
     * @param next     : next activity
     * @param flag     :flag for intent
     */
    public void navigateToNextScreen(Context current, Class<?> next, int flag) {
        Intent intent = new Intent(current, next);
        intent.addFlags(flag);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    /**
     * Use to transfer user to next screen
     *
     * @param current: current activity
     * @param next     : next activity
     * @param flag     :flag for intent
     * @param bundle
     */

    public void navigateToNextScreen(Context current, Class<?> next, int flag, Bundle bundle) {
        Intent intent = new Intent(current, next);
        intent.putExtra(DATA, bundle);
        intent.addFlags(flag);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    /**
     * Use to transfer user to next screen
     *
     * @param current: current activity
     * @param next     : next activity
     */
    public void navigateToNextScreen(Context current, Class<?> next) {
        Intent intent = new Intent(current, next);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    /**
     * Use to transfer user to next screen
     *
     * @param current: current activity
     * @param next     : next activity
     */
    public void navigateToNextScreen(Context current, Class<?> next, Bundle bundle) {
        Intent intent = new Intent(current, next);
        intent.putExtra(DATA, bundle);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    /**
     * Use to transfer user to next screen
     *
     * @param current: current activity
     * @param next     : next activity
     */
    public void navigateToNextScreenForResult(Context current, Class<?> next, int requestCode) {
        Intent intent = new Intent(current, next);
        startActivityForResult(intent, requestCode);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    /**
     * USe to transfer user to next screen
     *
     * @param current
     * @param next
     * @param bundle
     * @param requestCode
     */
    public void navigateToNextScreenForResult(Context current, Class<?> next, Bundle bundle, int requestCode) {
        Intent intent = new Intent(current, next);
        intent.putExtra(DATA, bundle);
        startActivityForResult(intent, requestCode);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    ///scroll scroll view to bottom
    public void scrollDown(final NestedScrollView scrollView) {
        scrollView.post(new Runnable() {

            @Override
            public void run() {
                scrollView.fullScroll(ScrollView.FOCUS_DOWN);
                // scrollViewCar.scrollTo(0, etRegistration.getBottom());
            }
        });
    }

    ///scroll scroll view to TOP
    public void scrollUp(final NestedScrollView scrollView) {
        scrollView.post(new Runnable() {

            @Override
            public void run() {
                scrollView.fullScroll(ScrollView.FOCUS_UP);
            }
        });
    }

    /**
     * this method use to replace/add fragment in back stack
     *
     * @param fragment
     */
    public void nextFragment(BaseFragment fragment) {
        try {
            String fragmentTag = fragment.getClass().getName();
            /*if (mStack.containsKey(fragmentTag))
                fragment = mStack.get(fragmentTag);
            else
                mStack.put(fragmentTag, fragment);*/
            FragmentManager manager = getSupportFragmentManager();

            FragmentTransaction ft = manager.beginTransaction();
            //ft.replace(R.id.fragContainer, fragment, fragmentTag);
//                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            ft.addToBackStack(fragmentTag);
            ft.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public boolean isPermissionRequired(String... permission) {
        return PermissionManager.getInstance().isPermissionRequired(this, permission);
    }

    public boolean shouldShowRequestPermissionRationale(String permission) {
        return PermissionManager.getInstance().shouldShowRequestPermissionRationale(this, permission);
    }

    public void showRationaleAlert(List<String> permissions, String message) {
        /*boolean rationale = false;
        for (String permission : permissions)
            rationale = rationale || shouldShowRequestPermissionRationale(permission);
        if (!rationale)
            getAlerts().showPermissionAlert(message);*/
    }

    public void requestPermission(int requestCode, OnPermissionRequestedCallback callback) {
        PermissionManager.getInstance().requestPermission(this, requestCode, callback);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        PermissionManager.getInstance().onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    /**
     * its use to handle click on dialog button
     */
    public interface ClickHandler {
        /**
         * will work for positive(ok/yes) click
         */
        void onPositiveClick();

        /**
         * will work for negative(no/cancel) click
         */
        void onNegativeClick();
    }
}