package com.example.amit.parshant.localtravelguid.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.os.AsyncTask;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.GlideBuilder;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.data.DataFetcher;
import com.bumptech.glide.load.model.GenericLoaderFactory;
import com.bumptech.glide.load.model.ModelLoader;
import com.bumptech.glide.load.model.ModelLoaderFactory;
import com.bumptech.glide.load.model.stream.StreamModelLoader;
import com.bumptech.glide.module.GlideModule;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;


public class GlideVideoThumbnail {

    public static class VideoImageLoader extends AsyncTask<String, Void, Bitmap> {
        private ImageView img;

        public VideoImageLoader(ImageView img) {
            this.img = img;
        }

        @Override
        protected Bitmap doInBackground(String... strings) {
            return Utils.getImageFromVideo(strings[0]);
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            if (bitmap != null)
                img.setImageBitmap(bitmap);
        }
    }

    public static class VideoThumbnail {
        private final String path;

        public VideoThumbnail(String path) {
            this.path = path;
        }
    }

    public static class VideoThumbnailModel implements GlideModule {

        @Override
        public void applyOptions(Context context, GlideBuilder builder) {

        }

        @Override
        public void registerComponents(Context context, Glide glide) {
            glide.register(VideoThumbnail.class, InputStream.class, new VideoThumbnailLoader.Factory());
        }
    }

    public static class VideoThumbnailLoader implements StreamModelLoader<VideoThumbnail> {

        @Override
        public DataFetcher<InputStream> getResourceFetcher(VideoThumbnail model, int width, int height) {
            return new VideoThumbnailFetcher(model);
        }

        public static class Factory implements ModelLoaderFactory<VideoThumbnail, InputStream> {

            @Override
            public ModelLoader<VideoThumbnail, InputStream> build(Context context, GenericLoaderFactory factories) {
                return new VideoThumbnailLoader();
            }

            @Override
            public void teardown() {

            }
        }
    }

    public static class VideoThumbnailFetcher implements DataFetcher<InputStream> {
        private final VideoThumbnail modal;
        private boolean cancelled = false;

        public VideoThumbnailFetcher(VideoThumbnail modal) {
            this.modal = modal;
        }

        @Override
        public InputStream loadData(Priority priority) throws Exception {
            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
            try {
                retriever.setDataSource(modal.path, new HashMap<String, String>());
                if (cancelled)
                    return null;
                Bitmap picture = retriever.getFrameAtTime();
                if (cancelled)
                    return null;
                if (picture != null) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    picture.compress(Bitmap.CompressFormat.JPEG, 90, bos);
                    if (cancelled)
                        return null;
                    InputStream in = new ByteArrayInputStream(bos.toByteArray());
                    return in;
                }
            } finally {
                retriever.release();
            }
            return null;
        }

        @Override
        public void cleanup() {

        }

        @Override
        public String getId() {
            return modal.path;
        }

        @Override
        public void cancel() {
            cancelled = true;
        }
    }
}
