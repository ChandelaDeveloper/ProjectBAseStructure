package com.example.amit.parshant.localtravelguid.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;

import com.example.amit.parshant.localtravelguid.R;


public class SplashActivity extends BaseActivity {

    //time in milliseconds
    private static final long TIME_FOR_WAIT = 2 * 1000;//number of seconds

    @Override
    protected int getLayoutResID() {
        return R.layout.activity_splash;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                navigateToExplore();
            }
        }, TIME_FOR_WAIT);
    }

    @Override
    protected void initUI() {

    }

    @Override
    protected void initListeners() {

    }

    /**
     * Use to navigate to next Screen
     */
    void navigateToExplore() {

        navigateToNextScreen(SplashActivity.this, LoginActivity.class, Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);

        finish();
    }


}


