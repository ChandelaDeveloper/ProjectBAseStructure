package com.example.amit.parshant.localtravelguid.permissions;

import java.util.List;

/**
 * Created by dev on 22/2/17.
 */

public interface OnPermissionRequestedCallback {
    void onPermissionGranted(int requestCode);
    void onPermissionRevoked(int requestCode, List<String> permissions);
}
