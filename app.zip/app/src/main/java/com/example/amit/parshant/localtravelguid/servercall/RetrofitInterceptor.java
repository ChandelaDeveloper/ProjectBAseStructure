package com.example.amit.parshant.localtravelguid.servercall;

import android.util.Log;

import com.example.amit.parshant.localtravelguid.activities.BaseActivity;
import com.example.amit.parshant.localtravelguid.utils.Constants;
import com.example.amit.parshant.localtravelguid.utils.Preferences;

import java.io.IOException;


import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Call;

/**
 * Created by signity on 5/12/17.
 */

public class RetrofitInterceptor implements Interceptor {

//    Chain mChain;

    @Override
    public Response intercept(Chain chain) throws IOException {
//        mChain = chain;
        Request originalRequest = chain.request();

        // Add authorization header with updated authorization value to intercepted request
        Request authorisedRequest = originalRequest.newBuilder()
                .header("token", Preferences.getInstance(BaseActivity.sContext).getValue(Constants.API_TOKEN, ""))
                .build();
        return chain.proceed(authorisedRequest);

//        Response response = chain.proceed(chain.request());
//        ResponseBody bodyStr = response.body();
//        try {
//            if (response.code() == 420) {
////                Converter<ResponseBody, ErrorUtils.APIError> converter =
////                        ServerApiClient.retrofit().responseBodyConverter(ErrorUtils.APIError.class, new Annotation[0]);
////
////                ErrorUtils.APIError error = converter.convert(bodyStr);
////                Log.e("inside", "interceptor " + error.status());
////                if (error.status() == 111) {
//                refreshToken();
////                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//
////        // Expired token case: server return with an expireToken info
////        String bodyStr = response.body().string();
////
////        if (bodyStr != null /*&& isNeedToRefresh(bodyStr)*/) {
//////            refreshToken();
////        }
//        try {
//            return response.newBuilder()
//                    .addHeader("token", Preferences.getInstance(BaseActivity.sContext).getValue(Constants.API_TOKEN, ""))
//                    .body(ResponseBody.create(bodyStr.contentType(), bodyStr.string()))
//                    .build();
//        } catch (Exception e) {
//            return null;
//        }
    }

    void refreshToken() {
        String token = Preferences.getInstance(BaseActivity.sContext).getValue(Constants.API_TOKEN, "");
        Call<RetroResponse.ApiResponse> refreshToken = ServerApiClient.getRetroInstance1().refreshUserToken(token);
        try {
            retrofit2.Response<RetroResponse.ApiResponse> result = refreshToken.execute();
            Log.e("data", "is " + result.body().data);
            Preferences.getInstance(BaseActivity.sContext).setValue(Constants.API_TOKEN, result.body().data);
//            intercept(mChain);
        } catch (IOException e) {
            e.printStackTrace();
        }
        /*refreshToken.enqueue(new Callback<RetroResponse.ApiResponse>() {
            @Override
            public void onResponse(Call<RetroResponse.ApiResponse> call, retrofit2.Response<RetroResponse.ApiResponse> response) {
                if (response.isSuccessful())
                    try {
                        Log.e("data", "is " + response.body().data);
//                        Preferences.getInstance(BaseActivity.sContext).editAction(Constants.API_TOKEN, );
                        intercept(mChain);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
            }

            @Override
            public void onFailure(Call<RetroResponse.ApiResponse> call, Throwable t) {

            }
        });*/
    }
}
