package com.example.amit.parshant.localtravelguid.utils.customViews;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

/**
 * Created by signity on 18/12/17.
 */

public class CustomViewPager extends ViewPager {
    private boolean swipe = true;

    public CustomViewPager(Context context) {
        super(context);
    }

    public CustomViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        return swipe ? super.onTouchEvent(ev) : false;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        return swipe ? super.onInterceptTouchEvent(ev) : false;
    }

    public void enableSwipe() {
        swipe = true;
    }

    public void disableSwipe() {
        swipe = false;
    }

    public boolean isSwipeEnabled() {
        return swipe;
    }
}