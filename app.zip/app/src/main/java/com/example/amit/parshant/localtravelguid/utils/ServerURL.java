package com.example.amit.parshant.localtravelguid.utils;

/**
 * Created by signity on 13/11/17.
 */

public class ServerURL {

    // development url
   public final static String BASE_URL = "http://dev.api.talupp.com";
   //public final static String BASE_URL = "http://staging.api.talupp.com";

    public final static String LOGIN_EMAIL = "/user/v1/login/email";
    public final static String FORGOT_PASSWORD = "/user/v1/forgot/password";
    public final static String GET_ROLE = "/user/v1/org/func/levels";
    public final static String ADD_ROLE = "/user/v1/career/latest";
    public final static String GET_COMMENTS = "/dev/v1/user/get/mileactions/comments/{id}/{tag}";
    public final static String ADD_COMMENT = "/dev/v1/user/add/comment";
    public final static String GET_EXPERIENCES = "/em/v1/experience/info/{company_id}";
    public final static String GET_REFLECTIONS = "/lotg/v1/reflections/past/fetch/three/{user_id}";
    public static final String GET_COMPETENCY = "/em/v1/experience/competencylist/{company_id}/{exp_id}";
    public static final String GET_PROJECTS = "/dev/v1/get/talupp/projects/{exp_id}/{user_id}/{company_id}/{exp_orig_id}/{pro_type}";
    public static final String ADD_PROJECTS = "dev/v1/company/add/user/project";
    public static final String EDIT_PROJECTS ="/dev/v1/post/edit/project";
    public static final String COMPLETE_MILESTONE ="/dev/v1/user/complete/milestone";
    public static final String COMPLETE_ACTION ="/dev/v1/user/complete/action";
    public static final String GET_MILESTONES = "/dev/v1/get/talupp/milestones/{exp_id}/{user_id}/{company_id}/{exp_orig_id}";
    public static final String ADD_MILESTONE = "dev/v1/company/add/user/milestone";
    public static final String GET_DEV_PLANS_USER_ID = "dev/v1/get/user/devplan/byuser/{user_id}";
    public static final String GET_DEV_PLAN = "dev/v1/get/user/devplan/{id}";
    public static final String GET_ACTIONS = "dev/v1/get/milestone/user/actions/{milestone_id}/{dev_plan_id}";
    public static final String SAVE_CHANGES_DEV_PLAN = "dev/v1/user/dev/plan/create";
    public static final String ADD_ACTION = "dev/v1/user/add/milestone/action";
    public static final String DELETE_ACTION = "dev/v1/user/remove/milestone/action";
    public static final String EDIT_ACTION = "dev/v1/user/milestone/edit/action";
    public static final String GET_REFLECTION_QUESTIONS = "/lotg/v1/reflections/questions/{company_id}";
    public final static String GET_LIBRARY = "/ml/v1/library/explore";
    public final static String LIKE_VIDEO = "/ml/v1/library/content/like";
    public final static String DISLIKE_VIDEO = "/ml/v1/library/content/dislike";
    public static final String MY_LIKED_VIDEOS = "/ml/v1/library/get/liked/content";
    public static final String MY_VIDEO_HISTORY = "/ml/v1/library/getuser/history";
    public static final String GET_FULL_COMPETENCIES = "/ml/v1/library/getfulllist/competencies/{company_id}";
    public static final String GET_LEADERSHIP_EXP = "/em/v1/experience/info/{company_id}";
    public static final String POST_HISTORY = "/ml/v1/library/history/post";
    public static final String VIEW_ALL_REFLECTIONS = "/lotg/v1/reflections/past/{user_id}";

    public static final String REFRESH_TOKEN = "/user/v1/refresh/token";
    public static final String POST_USER_ANSWER = "/lotg/v1/reflections/questions";
    public static final String SINGLE_REFLECTION = "/lotg/v1/reflections/single/past/{user_id}/{ref_id}";
    public static final String UPDATE_SINGLE_REFLECTION = "/lotg/v1/reflections/single/update";
    public static final String REMOVE_SINGLE_REFLECTION = "/lotg/v1/remove/single/review\n";
    public static final String ANALYTICS = "/as/v1/analytics";
    public static final String SINGLE_ANALYTICS = "/as/v1/analytics/single";
    public static final String SINGLE_OPTION_ANALYTICS = "/as/v1/analytics/single/option";
    public static final String PDF_DATA = "/lotg/v1/make/html/string/reflections";

    public static final String ADD_ROLES = "/le/v1/career/add";
    public static final String UPDATE_ROLES = "/le/v1/role/update/single";
    public static final String USER_ROLES = "/le/v1/career/getroles";
    public static final String EXP_DETAILS = "/le/v1/career/roles";
    public static final String UPDATE_EXP_ROLES = "/le/v1/career/update/exp";
    public static final String QUESTIONS_DATA = "/le/v1/exp/getquestions";
    public static final String SUBMIT_QUESTIONS_DATA = "/le/v1/exp/questions/submit";
    public static final String EMAIL_TO_WEB_PORTAL = "/user/v1/send/web/portal/link/user";
    public static final String PROFILE_EDIT = "/user/v1/profile/edit";
    public static final String PASSWORD_UPDATE = "/user/v1/post/user/change/password";
    public static final String FEEDBACK = "/user/v1/post/user/feedback/settings";
    public static final String ExtraText = "/user/v1/getinfo/company/app";

}