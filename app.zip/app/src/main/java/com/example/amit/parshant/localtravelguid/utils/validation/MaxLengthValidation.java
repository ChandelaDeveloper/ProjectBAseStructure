package com.example.amit.parshant.localtravelguid.utils.validation;

/**
 * Created by JSN on 12/9/17.
 */

public class MaxLengthValidation implements IValueValidator {

    private int length;

    public MaxLengthValidation(int length) {
        this.length = length;
    }

    @Override
    public boolean validate(String value) {

        if (value.length() < length) {
            return false;
        }

        return true;
    }

    @Override
    public String getErrorMsg() {
        return "Length must be greater than or equal to " + length;
    }
}
