package com.example.amit.parshant.localtravelguid.servercall;

import android.content.Intent;

import com.example.amit.parshant.localtravelguid.activities.BaseActivity;
import com.example.amit.parshant.localtravelguid.utils.Constants;
import com.example.amit.parshant.localtravelguid.utils.Preferences;

import java.io.IOException;


import okhttp3.Authenticator;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;
import retrofit2.Call;

/**
 * Created by signity on 5/12/17.
 */

public class RetrofitAuthenticator implements Authenticator {
    boolean isLogout = false;

    @Override
    public Request authenticate(Route route, Response response) throws IOException {
        try {
            refreshToken();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isLogout ? null : response.request().newBuilder()
                .addHeader("token", Preferences.getInstance(BaseActivity.sContext).getValue(Constants.API_TOKEN, ""))
                .build();
    }

    void refreshToken() {
        String token = Preferences.getInstance(BaseActivity.sContext).getValue(Constants.API_TOKEN, "");
        Call<RetroResponse.ApiResponse> refreshToken = ServerApiClient.getRetroInstance1().refreshUserToken(token);
        try {
            retrofit2.Response<RetroResponse.ApiResponse> result = refreshToken.execute();
            if (result.body().getStatus() == 1111) {
                isLogout = true;
                //logout if password is changes
                Preferences.getInstance(BaseActivity.sContext).clearValues();
                Preferences.getInstance(BaseActivity.sContext).setValue(Constants.USER_LOGIN_STATE, Constants.LOGOUT);
                BaseActivity.getInstance().navigateToLogin(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            } else {
                Preferences.getInstance(BaseActivity.sContext).setValue(Constants.API_TOKEN, result.body().data);
                isLogout = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
