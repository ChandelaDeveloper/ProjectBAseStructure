package com.example.amit.parshant.localtravelguid.utils.validation;

import java.util.regex.Pattern;

/**
 * Created by JSN on 12/9/17.
 */

public class NumberValidation implements IValueValidator {

    private static final String NUMBER_PATTERN = "([0-9]{10,10})";

    @Override
    public boolean validate(String number) {
        if (!validNumber(number)) {
            return false;
        }
        return true;
    }

    @Override
    public String getErrorMsg() {
        return "Invalid Number!";
    }

    private boolean validNumber(String number) {
        Pattern pattern = Pattern.compile(NUMBER_PATTERN);
        return pattern.matcher(number).matches();
    }
}
