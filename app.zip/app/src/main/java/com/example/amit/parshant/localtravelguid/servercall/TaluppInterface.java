package com.example.amit.parshant.localtravelguid.servercall;


import com.example.amit.parshant.localtravelguid.utils.ServerURL;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Created by signity on 13/11/17.
 */

public interface TaluppInterface {

    @FormUrlEncoded
    @POST(ServerURL.LOGIN_EMAIL)
    Call<RetroResponse.LoginResponse> login(@Field("email") String email, @Field("password") String password);

    @FormUrlEncoded
    @POST(ServerURL.FORGOT_PASSWORD)
    Call<RetroResponse.ApiResponse> forgotPassword(@Field("email") String email);

    @FormUrlEncoded
    @POST(ServerURL.ADD_ROLE)
    Call<RetroResponse.ApiResponse> addRole(@Field("user_id") String user_id, @Field("title") String title, @Field("org_level") int org_level, @Field("func_area") int func_area, @Field("location") String location);

    @FormUrlEncoded
    @POST(ServerURL.ADD_COMMENT)
    Call<RetroResponse.ApiResponse> addComment(@Field("user_id") String user_id, @Field("tag") String tag, @Field("item_id") String item_id, @Field("text") String text);

    @FormUrlEncoded
    @POST(ServerURL.ADD_PROJECTS)
    Call<RetroResponse.ApiResponse> addProject(@Field("title") String title, @Field("company_id") String company_id, @Field("exp_id") String exp_id, @Field("pro_type") String pro_type);

    @FormUrlEncoded
    @POST(ServerURL.EDIT_PROJECTS)
    Call<RetroResponse.ApiResponse> editProject(@Field("title") String title, @Field("company_id") String company_id, @Field("exp_id") String exp_id, @Field("pro_type") String pro_type, @Field("dev_plan_id") String devId);

    /* @FormUrlEncoded
     @POST(ServerURL.EDIT_PROJECTS)
     Call<RetroResponse.ApiResponse> editProject(@Field("title") String title, @Field("id") String company_id,@Field("dev_plan_id")String devId);
 */
    @FormUrlEncoded
    @POST(ServerURL.COMPLETE_MILESTONE)
    Call<RetroResponse.ApiResponse> setMilestoneStatus(@Field("id") String id);

    @FormUrlEncoded
    @POST(ServerURL.COMPLETE_ACTION)
    Call<RetroResponse.ApiResponse> setActionStatus(@Field("id") String id);

    @FormUrlEncoded
    @POST(ServerURL.ADD_MILESTONE)
    Call<RetroResponse.ApiResponse> addMilestone(@Field("title") String title, @Field("company_id") String company_id, @Field("exp_id") String exp_id);

    @FormUrlEncoded
    @POST(ServerURL.ADD_ACTION)
    Call<RetroResponse.ApiResponse> addAction(@Field("title") String title, @Field("milestone_id") String milestone_id, @Field("end_date") String end_date, @Field("notes") String notes, @Field("user_id") String userId);

    @FormUrlEncoded
    @POST(ServerURL.DELETE_ACTION)
    Call<RetroResponse.ApiResponse> deleteAction(@Field("id") String action_id, @Field("user_id") String userId);

    @FormUrlEncoded
    @POST(ServerURL.EDIT_ACTION)
    Call<RetroResponse.ApiResponse> updateAction(@Field("title") String title, @Field("id") String id, @Field("end_date") String end_date, @Field("notes") String notes, @Field("user_id") String userId);


    @FormUrlEncoded
    @POST(ServerURL.SAVE_CHANGES_DEV_PLAN)
    Call<RetroResponse.DevPlanResponse> saveChanges(@Field("exp_id") String exp_id, @Field("project") String project, @Field("milestones") String milestones, @Field("actions") String actions, @Field("role") String role, @Field("user_id") String userId);

    @GET(ServerURL.GET_ROLE)
    Call<RetroResponse.GetRoleApiResponse> getRole();

    @GET(ServerURL.GET_COMMENTS)
    Call<RetroResponse.GetComments> getComments(@Path("id") String id, @Path("tag") String tag);


    @GET(ServerURL.GET_LIBRARY + "/{user_id}")
    Call<RetroResponse.LibraryResponse> getMainLibrary(@Path("user_id") String userId);


    @GET(ServerURL.MY_LIKED_VIDEOS + "/{user_id}")
    Call<RetroResponse.FetchLikeVideoResponse> getLikedVideo(@Path("user_id") String userId);

    @GET(ServerURL.MY_VIDEO_HISTORY + "/{user_id}")
    Call<RetroResponse.FetchLikeVideoResponse> getVideoHistory(@Path("user_id") String userId);

    @GET(ServerURL.GET_EXPERIENCES)
    Call<RetroResponse.GetExperiencesResponse> getExperiences(@Path("company_id") String company_id);

    @GET(ServerURL.GET_DEV_PLAN)
    Call<RetroResponse.GetDevPlans> getDevPlans(@Path("id") String Id);

    @GET(ServerURL.GET_DEV_PLANS_USER_ID)
    Call<RetroResponse.GetDevPlans> getDevPlansUser(@Path("user_id") String userId);


    @GET(ServerURL.GET_COMPETENCY)
    Call<RetroResponse.GetExperiencesResponse> getCompetences(@Path("company_id") String company_id, @Path("exp_id") String exp_id);

    @GET(ServerURL.GET_PROJECTS)
    Call<RetroResponse.GetProjectsOrMilestones> getProjects(@Path("company_id") String company_id, @Path("exp_id") String exp_id, @Path("exp_orig_id") String exp_orig_id, @Path("pro_type") String pro_type, @Path("user_id") String userId);

    @GET(ServerURL.GET_MILESTONES)
    Call<RetroResponse.GetProjectsOrMilestones> getMilestones(@Path("company_id") String company_id, @Path("exp_id") String exp_id, @Path("user_id") String userId, @Path("exp_orig_id") String exp_orig_id);

    @GET(ServerURL.GET_ACTIONS)
    Call<RetroResponse.GetMilestoneActions> getActions(@Path("milestone_id") String milestone_id, @Path("dev_plan_id") String dev_id);

    @GET(ServerURL.GET_REFLECTIONS)
    Call<RetroResponse.GetAllReflections> getThreeReflections(@Path("user_id") String user_id);

    @GET(ServerURL.GET_REFLECTION_QUESTIONS)
    Call<RetroResponse.ReflectionQuestion> getReflectionQuestions(@Path("company_id") String company_id);

    @FormUrlEncoded
    @POST(ServerURL.LIKE_VIDEO)
    Call<RetroResponse.ApiResponse> likeVideo(@Field("user_id") String userId, @Field("library_content_id") int libraryContentId);

    @FormUrlEncoded
    @POST(ServerURL.DISLIKE_VIDEO)
    Call<RetroResponse.ApiResponse> dislikeVideo(@Field("user_id") String userId, @Field
            ("library_content_id") int
            libraryContentId);

    @GET(ServerURL.GET_FULL_COMPETENCIES)
    Call<RetroResponse.GetFullCompetencyList> getFullCompetences(@Path("company_id") String company_id);

    @GET(ServerURL.GET_LEADERSHIP_EXP)
    Call<RetroResponse.GetLeadershipExperience> getLeadershipExp(@Path("company_id") String company_id);

    @FormUrlEncoded
    @POST(ServerURL.REFRESH_TOKEN)
    Call<RetroResponse.ApiResponse> refreshUserToken(@Field("token") String token);

    @FormUrlEncoded
    @POST(ServerURL.POST_HISTORY)
    Call<RetroResponse.ApiResponse> postHistory(@Field("user_id") String user_id, @Field("library_content_id") String library_content_id);

    @GET(ServerURL.VIEW_ALL_REFLECTIONS)
    Call<RetroResponse.GetAllReflections> getAllReflections(@Path("user_id") String userId);

    @FormUrlEncoded
    @POST(ServerURL.POST_USER_ANSWER)
    Call<RetroResponse.ApiResponse> postUserAnswer(@Field("user_id") String userId, @Field("title") String title, @Field("type") String type, @Field("is_shared") String isShared, @Field("answers") String answers);

    @GET(ServerURL.SINGLE_REFLECTION)
    Call<RetroResponse.SingleReflection> getSingleReflection(@Path("user_id") String userId, @Path("ref_id") String refId);

    //    @FormUrlEncoded
    @POST(ServerURL.UPDATE_SINGLE_REFLECTION)
    Call<RetroResponse.ApiResponse> updateSingleReflection(@Body RetroResponse.SingleReflectionBody body);
//    Call<RetroResponse.ApiResponse> updateSingleReflection(@Field("ids[]") long[] ids, @Field("answers") String answers, @Field("question_type") String questionType, @Field("title_update") int titleUpdate);

    @FormUrlEncoded
    @POST(ServerURL.POST_USER_ANSWER)
    Call<RetroResponse.ApiResponse> postUserAnswer(@Field("note") String note, @Field("user_id") String userId, @Field("title") String title, @Field("type") String type, @Field("is_shared") String isShared, @Field("answers") String answers);

    @FormUrlEncoded
    @POST(ServerURL.POST_USER_ANSWER)
    Call<RetroResponse.ApiResponse> postUserAudio(@Field("audio_url") String audioUrl, @Field("user_id") String userId, @Field("title") String title, @Field("type") String type, @Field("is_shared") String isShared, @Field("answers") String answers);

    @FormUrlEncoded
    @POST(ServerURL.REMOVE_SINGLE_REFLECTION)
    Call<RetroResponse.ApiResponse> removeSingleReflection(@Field("id") String id);

    //    @FormUrlEncoded
    @POST(ServerURL.ANALYTICS)
    Call<RetroResponse.Analytics> getAnalytics(@Body RetroResponse.AnalyticsBody body);
//    Call<RetroResponse.Analytics> getAnalytics(@Field("time") int time, @Field("type") String type, @Field("exp_id") String expId, @Field("comp_id") String compId, @Field("user_id") String userId, @Field("company_id") int companyId);

    //    @FormUrlEncoded
    @POST(ServerURL.SINGLE_ANALYTICS)
    Call<RetroResponse.SingleAnalytics> getSingleAnalytics(@Body RetroResponse.AnalyticsBody body);
//    Call<RetroResponse.SingleAnalytics> getSingleAnalytics(@Field("time") Integer time, @Field("type") String type, @Field("exp_id") String expId, @Field("comp_id") String compId, @Field("user_id") String userId, @Field("company_id") String companyId, @Field("question_id") Integer questionId, @Field("opt_id") Integer optionId);

    //    @FormUrlEncoded
    @POST(ServerURL.SINGLE_OPTION_ANALYTICS)
    Call<RetroResponse.SingleOptionAnalytics> getSingleOptionAnalytics(@Body RetroResponse.AnalyticsBody body);
//    Call<RetroResponse.SingleOptionAnalytics> getSingleOptionAnalytics(@Field("time") int time, @Field("type") String type, @Field("exp_id") String expId, @Field("comp_id") String compId, @Field("user_id") String userId, @Field("company_id") int companyId, @Field("question_id") int questionId, @Field("opt_id") int optionId, @Field("type_opt") String optionType, @Field("title") String title);

    @FormUrlEncoded
    @POST(ServerURL.PDF_DATA)
    Call<RetroResponse.ApiResponse> getPDFData(@Field("user_id") String userId);




}