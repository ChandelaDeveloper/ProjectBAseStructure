package com.example.amit.parshant.localtravelguid.utils.validation;

import android.widget.EditText;

/**
 * Created by JSN on 12/9/17.
 */

public class Field extends BaseValidation {

    private EditText field;
    private boolean isRequired = true;

    public Field(EditText field) {
        this.field = field;
    }

    public Field(EditText field, boolean isRequired) {
        this.field = field;
        this.isRequired = isRequired;
    }

    @Override
    public boolean validate() {
        String value = field.getText().toString();

        if (StringUtils.invalidString(value) && isRequired) {
            warnFieldRequired();
            return false;
        }

        return allValidated(value);
    }

    @Override
    public void setError(String msg) {
        field.setError(msg);
    }
}
