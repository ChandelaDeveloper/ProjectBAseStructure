package com.example.amit.parshant.localtravelguid.utils;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.provider.CalendarContract;
import android.support.design.widget.TabLayout;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;



import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;



/**
 * Created by signity on 13/11/17.
 */

public class Utils {

    /**
     *
     * @param mdate
     * @return
     */
    public static String convertDateFormat(String mdate){
        try {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            Date date = dateFormat.parse(""+mdate);//You will get date object relative to server/client timezone wherever it is parsed
            DateFormat formatter = new SimpleDateFormat("MMMM yyyy"); //If you need time just put specific format for time like 'HH:mm:ss'
            String dateStr = formatter.format(date);
            return dateStr;
        } catch (ParseException e) {
            e.printStackTrace();
            return "";
        }
    }

    /**
     *
     * @param mdate
     * @return
     */
    public static String convertDate(String mdate){
        try {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            Date date = dateFormat.parse(""+mdate);//You will get date object relative to server/client timezone wherever it is parsed
            DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); //If you need time just put specific format for time like 'HH:mm:ss'
            String dateStr = formatter.format(date);
            return dateStr;
        } catch (ParseException e) {
            e.printStackTrace();
            return "";
        }
    }

    /**
     * @return type is boolean , true if connected with internet else false
     * @Desc: isConnectedToInternet Checking for all possible internet providers
     * @context: context of activity
     */

    public static boolean isConnectedToInternet(Context _context) {
        if (_context != null) {
            ConnectivityManager cm = (ConnectivityManager) _context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo info = cm.getActiveNetworkInfo();
            if (info != null)
                return info.isConnected();
            else
                return false;
        } else
            return false;
    }

    /**
     * use to convert dp in pixels
     *
     * @param context
     * @param dpValue
     * @return
     */
    public static int dp2px(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    /**
     * use to convert pixels in dp
     *
     * @param context
     * @param myPixels
     * @return
     */
    public static float px2dp(Context context, float myPixels) {
        return myPixels / context.getResources().getDisplayMetrics().density;
    }

    /**
     * use to check if string contains at least One Alpha
     *
     * @param password
     * @return true/false
     */
    public static boolean atleastOneAlpha(String password){
        boolean atleastOneAlpha = password.matches(".*[a-zA-Z]+.*");
        return atleastOneAlpha;
    }

    /**
     * use to check if string contains at least One Digit
     *
     * @param password
     * @return true/false
     */
    public static boolean atleastOneDigit(String password){
        boolean atleastOneDigit = password.matches(".*[0-9]+.*");
        return atleastOneDigit;
    }

    /**
     * Use to hide keyboard on click event
     *
     * @param activity
     */
    public static void hide_keyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity
                .getSystemService(Activity.INPUT_METHOD_SERVICE);
        View view = activity.getCurrentFocus();
        if (view == null) {
            view = new View(activity);
        }
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    /**
     * Add event to google calender
     * @param context
     * @param title
     * @param millis
     * @param allDay
     * @return
     */
    public static long addToCalendar(Context context, String title, long millis, boolean allDay) {
        ContentResolver resolver = context.getContentResolver();
        ContentValues values = new ContentValues();
        Calendar cal = Calendar.getInstance();
        values.put(CalendarContract.Events.DTSTART, millis);
        values.put(CalendarContract.Events.DTEND, millis + 60 * 60 * 1000);
        values.put(CalendarContract.Events.TITLE, title);
        values.put(CalendarContract.Events.CALENDAR_ID, getCalendarId());
        values.put(CalendarContract.Events.HAS_ALARM, 1);
        values.put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().getID());
        values.put(CalendarContract.Events.ALL_DAY, allDay);
        Uri uri = resolver.insert(CalendarContract.Events.CONTENT_URI, values);
        long eventID = Long.parseLong(uri.getLastPathSegment());
        values = new ContentValues();
        values.put(CalendarContract.Reminders.EVENT_ID, eventID);
        values.put(CalendarContract.Reminders.MINUTES, 10);
        values.put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT);
        uri = resolver.insert(CalendarContract.Reminders.CONTENT_URI, values);
        return uri != null ? Long.parseLong(uri.getLastPathSegment()) : 0;
    }

    private static int getCalendarId() {
        return 1;
    }

    public static String getFormattedData(boolean[] data) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < data.length; i++) {
            if (data[i]) {
                builder.append(i + "");
            }
            if (i < data.length)
                builder.append(",");
        }
        return builder.toString();
    }

    public static boolean[] getFormattedData(String data, int size) {
        boolean[] array = new boolean[size];
        String[] d = data.split(",");
        for (int i = 0; i < size; i++) {
            if (checkInArray(i + "", d))
                array[i] = true;
        }
        return array;
    }

    private static boolean checkInArray(String s, String[] arr) {
        for (String a : arr) {
            if (a.equals(s))
                return true;
        }
        return false;
    }

    public static Drawable getTintedDrawable(Context context, int drawable, int color) {
        Drawable image = ContextCompat.getDrawable(context, drawable);
        image.mutate();
        DrawableCompat.setTint(image, color);
        return image;
    }

    /**
     * Use to delete local file store in device
     * @param path
     * @return
     */

    public static boolean deleteFilesInDir(File path) {
        if (path.exists()) {
            File[] files = path.listFiles();
            if (files == null)
                return true;
            for (int i = 0; i < files.length; i++) {
                if (!files[i].isDirectory())
                    files[i].delete();
            }
        }
        return true;
    }

    /**
     * use to convert date in perticuler required format
     * @param dateStr
     * @param oldDateFormat
     * @param newDateFormat
     * @return
     */
    public static String formatDate(String dateStr,final String oldDateFormat,final String newDateFormat) {

        Date date = null;

        SimpleDateFormat sdfOld = new SimpleDateFormat(oldDateFormat);
        try {
            date = sdfOld.parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        SimpleDateFormat sdfNew = new SimpleDateFormat(newDateFormat);
        return date == null ? "" : sdfNew.format(date);
    }






    /**
     * this mathod is use to get thumbnail of video by using video url(Heavy process)
     * @param videoUrl -
     * @return bitmap of image
     */
    public static Bitmap getImageFromVideo(String videoUrl) {
        Bitmap bitmap = null;
        MediaMetadataRetriever mediaMetadataRetriever = null;
        try {
            mediaMetadataRetriever = new MediaMetadataRetriever();
            mediaMetadataRetriever.setDataSource(videoUrl, new HashMap<String, String>());
            bitmap = mediaMetadataRetriever.getFrameAtTime();
        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            if (mediaMetadataRetriever != null)
                mediaMetadataRetriever.release();
        }
        return bitmap;
    }


    public static final class TabLayoutUtils {

        public static void enableTabs(TabLayout tabLayout, boolean enable) {
            ViewGroup viewGroup = getTabViewGroup(tabLayout);
            if (viewGroup != null)
                for (int childIndex = 0; childIndex < viewGroup.getChildCount(); childIndex++) {
                    View tabView = viewGroup.getChildAt(childIndex);
                    if (tabView != null)
                        tabView.setEnabled(enable);
                }
        }

        public static View getTabView(TabLayout tabLayout, int position) {
            View tabView = null;
            ViewGroup viewGroup = getTabViewGroup(tabLayout);
            if (viewGroup != null && viewGroup.getChildCount() > position)
                tabView = viewGroup.getChildAt(position);
            return tabView;
        }

        private static ViewGroup getTabViewGroup(TabLayout tabLayout) {
            ViewGroup viewGroup = null;
            if (tabLayout != null && tabLayout.getChildCount() > 0) {
                View view = tabLayout.getChildAt(0);
                if (view != null && view instanceof ViewGroup)
                    viewGroup = (ViewGroup) view;
            }
            return viewGroup;
        }

    }
}