package com.example.amit.parshant.localtravelguid.utils.validation;


import android.widget.EditText;

/**
 * Created by JSN on 12/9/17.
 */

public class PasswordValidation extends BaseValidation {

    private EditText editText1, editText2;
    private boolean isSingleFieldValidation = false;

    public PasswordValidation(EditText editText1, EditText editText2) {
        this.editText1 = editText1;
        this.editText2 = editText2;
    }

    public PasswordValidation(EditText editText1, boolean isSingleFieldValidation) {
        this.editText1 = editText1;
        this.isSingleFieldValidation = isSingleFieldValidation;
    }

    @Override
    public boolean validate() {

        String pass1 = editText1.getText().toString();


        if (isSingleFieldValidation) {
            if (StringUtils.invalidString(pass1)) {
                setErrorMsgF1("This field is required!");
                return false;
            }
        } else {
            String pass2 = editText2.getText().toString();

            if (StringUtils.invalidString(pass1) && StringUtils.invalidString(pass2)) {
                setErrorMsgF1("This field is required!");
                setErrorMsgF2("This field is required!");
                return false;
            } else if (StringUtils.invalidString(pass1) || StringUtils.invalidString(pass2) || !pass1.trim().equals(pass2.trim())) {
                setErrorMsgF2("Invalid password!");
                return false;
            }
        }

        for (IValueValidator validator : validators) {
            boolean isValidated = validator.validate(pass1);
            if (!isValidated) {
                if (isSingleFieldValidation) {
                    setErrorMsgF1(validator.getErrorMsg());
                } else {
                    setErrorMsgF2(validator.getErrorMsg());
                }
            }
        }

        return true;
    }

    @Override
    public void setError(String msg) {

    }

    public void setErrorMsgF1(String msg) {
        editText1.setError(msg);
    }

    public void setErrorMsgF2(String msg) {
        editText2.setError(msg);
    }

}
